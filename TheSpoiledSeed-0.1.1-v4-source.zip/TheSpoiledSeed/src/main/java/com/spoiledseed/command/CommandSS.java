package com.spoiledseed.command;

import com.spoiledseed.config.ModConfig;
import com.spoiledseed.guide.GuideHandler;
import com.spoiledseed.horror.FogController;
import com.spoiledseed.horror.HorrorDirector;
import com.spoiledseed.horror.HorrorEvent;
import com.spoiledseed.horror.PlayerHorror;
import com.spoiledseed.horror.SpawnHelper;
import com.spoiledseed.horror.WorldPranks;
import com.spoiledseed.entity.EntityNull;
import com.spoiledseed.entity.NullState;
import com.spoiledseed.registry.ModSounds;
import com.spoiledseed.quest.QuestData;
import com.spoiledseed.quest.QuestManager;
import com.spoiledseed.registry.ModBlocks;
import com.spoiledseed.registry.ModItems;
import com.spoiledseed.world.StructureGenerator;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import net.minecraft.command.CommandBase;
import net.minecraft.command.CommandException;
import net.minecraft.command.ICommandSender;
import net.minecraft.command.WrongUsageException;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.item.ItemStack;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.util.text.event.ClickEvent;

/**
 * /ss (alias /spoiledseed). Every event name works directly, as often as you like (no cooldowns):
 *   jumpscare chase stalk observe glimpse bed footsteps knock whisper sound cave torch door theft sign
 *   fog <0-100|off> | stage <0-5> | threat <0-12> | locate <site|shrine|cairn|ruin>
 *   spawn <observing|stalking|disturbance|jumpscare|chase|rush>   (monster in a given state)
 *   play <jumpscare|footstep|chase|vanish|heartbeat|whisper|breath|knock|scrape|tap|creak|sting|drone|seal>
 *   opt <fog|jumpscare|theft|signs|ambient|fogstrength|level> <on|off|0-100|0-2>   (what Mod Options uses)
 *   give | guide | clear | status | reset | help
 */
public class CommandSS extends CommandBase {
    @Override public String getCommandName() { return "spoiledseed"; }
    @Override public List<String> getCommandAliases() { return Arrays.asList("ss"); }
    @Override public String getCommandUsage(ICommandSender sender) { return "/ss help"; }
    @Override public int getRequiredPermissionLevel() { return ModConfig.openCommands ? 0 : 2; }

    @Override
    public List<String> getTabCompletionOptions(MinecraftServer server, ICommandSender sender, String[] args, BlockPos pos) {
        List<String> all = new ArrayList<String>();
        for (HorrorEvent e : HorrorEvent.values()) all.add(e.key);
        all.addAll(Arrays.asList("fog", "stage", "threat", "locate", "opt", "spawn", "play", "give", "guide", "clear", "status", "reset", "help"));
        if (args.length == 1) return getListOfStringsMatchingLastWord(args, all);
        if (args.length == 2 && args[0].equalsIgnoreCase("locate")) return getListOfStringsMatchingLastWord(args, "site", "shrine", "cairn", "ruin");
        if (args.length == 2 && args[0].equalsIgnoreCase("fog")) return getListOfStringsMatchingLastWord(args, "off", "30", "60", "100");
        if (args.length == 2 && args[0].equalsIgnoreCase("opt")) return getListOfStringsMatchingLastWord(args, "fog", "jumpscare", "theft", "signs", "ambient", "fogstrength", "level");
        if (args.length == 2 && args[0].equalsIgnoreCase("spawn")) return getListOfStringsMatchingLastWord(args, "observing", "stalking", "disturbance", "jumpscare", "chase", "rush");
        if (args.length == 2 && args[0].equalsIgnoreCase("play")) return getListOfStringsMatchingLastWord(args, ModSounds.PLAYABLE);
        if (args.length == 3 && args[0].equalsIgnoreCase("opt")) return getListOfStringsMatchingLastWord(args, "on", "off", "0", "1", "2");
        return new ArrayList<String>();
    }

    @Override
    public void execute(MinecraftServer server, ICommandSender sender, String[] args) throws CommandException {
        EntityPlayerMP p = getCommandSenderAsPlayer(sender);
        if (args.length == 0) { help(p); return; }
        String a = args[0].toLowerCase();

        HorrorEvent ev = HorrorEvent.byKey(a);
        if (ev == null && a.equals("event") && args.length > 1) ev = HorrorEvent.byKey(args[1]);   // old syntax still works
        if (ev != null) { HorrorDirector.run(p, ev, true); return; }

        if (a.equals("opt")) {
            option(p, args);
        } else if (a.equals("spawn")) {
            spawn(p, args);
        } else if (a.equals("play")) {
            if (args.length < 2 || !WorldPranks.playNamed(p, args[1].toLowerCase())) throw new WrongUsageException("/ss play <jumpscare|footstep|chase|vanish|heartbeat|whisper|breath|knock|scrape|tap|creak|sting|drone|seal>");
        } else if (a.equals("fog")) {
            if (args.length < 2) throw new WrongUsageException("/ss fog <0-100|off>");
            PlayerHorror r = HorrorDirector.rec(p);
            if (args[1].equalsIgnoreCase("off")) { r.fogForce = -1F; say(p, "Fog back to automatic."); }
            else { r.fogForce = parseInt(args[1], 0, 100) / 100F; say(p, "Fog fixed at " + args[1] + "%. (/ss fog off to release)"); }
            FogController.sendNow(p, r, r.fogForce >= 0F ? r.fogForce : 0F);
        } else if (a.equals("stage")) {
            if (args.length < 2) throw new WrongUsageException("/ss stage <0-5>");
            QuestData.setStage(p, parseInt(args[1], 0, 5));
            say(p, "Stage set to " + QuestData.getStage(p));
        } else if (a.equals("threat")) {
            if (args.length < 2) throw new WrongUsageException("/ss threat <0-12>");
            QuestData.setThreat(p, parseInt(args[1], 0, QuestData.MAX_THREAT));
            say(p, "Threat set to " + QuestData.getThreat(p));
        } else if (a.equals("locate")) {
            if (args.length < 2) throw new WrongUsageException("/ss locate <site|shrine|cairn|ruin>");
            StructureGenerator.Kind k;
            try { k = StructureGenerator.Kind.valueOf(args[1].toUpperCase()); }
            catch (IllegalArgumentException ex) { throw new WrongUsageException("/ss locate <site|shrine|cairn|ruin>"); }
            StructureGenerator.Slot s = StructureGenerator.locate(p.worldObj, new BlockPos(p), k);
            if (s == null) say(p, "Nothing planned nearby.");
            else say(p, k + " planned at x=" + s.blockX() + " z=" + s.blockZ() + "  (" + (int) Math.sqrt(p.getDistanceSq(s.blockX(), p.posY, s.blockZ())) + " blocks away)");
        } else if (a.equals("give")) {
            ItemStack[] all = new ItemStack[] {
                new ItemStack(ModItems.corruptedSample, 3), new ItemStack(ModItems.relicEcho), new ItemStack(ModItems.relicCore),
                new ItemStack(ModItems.relicSeal), new ItemStack(ModItems.journalTorn), new ItemStack(ModItems.journalAncient),
                new ItemStack(ModBlocks.ancientAltar) };
            for (ItemStack s : all) if (!p.inventory.addItemStackToInventory(s)) p.entityDropItem(s, 0F);
            QuestManager.syncSeen(p);                       // given items do not count as finds (no threat)
            say(p, "Quest items given.");
        } else if (a.equals("guide")) {
            GuideHandler.give(p);
            say(p, "New Survivor's Guide given.");
        } else if (a.equals("clear")) {
            HorrorDirector.clearNull(p);
            say(p, "The Null was removed.");
        } else if (a.equals("reset")) {
            QuestData.setStage(p, 0);
            QuestData.setSealed(p, false);
            QuestData.setThreat(p, 0);
            QuestManager.syncSeen(p);
            HorrorDirector.rec(p).fogForce = -1F;
            say(p, "Progress and threat reset (play time kept).");
        } else if (a.equals("status")) {
            say(p, "stage=" + QuestData.getStage(p) + "  threat=" + QuestData.getThreat(p) + "/" + QuestData.MAX_THREAT
                    + "  playtime=" + QuestData.getSeconds(p) + "s  sealed=" + QuestData.isSealed(p)
                    + "  night=" + HorrorDirector.isNight((net.minecraft.world.WorldServer) p.worldObj)
                    + "  nearHome=" + HorrorDirector.isNearHome(p));
        } else {
            help(p);
        }
    }

    private void option(EntityPlayerMP p, String[] args) throws CommandException {
        if (args.length < 3) throw new WrongUsageException("/ss opt <fog|jumpscare|theft|signs|ambient|fogstrength|level> <on|off|0-100>");
        String name = args[1].toLowerCase();
        String val = args[2].toLowerCase();
        if (name.equals("level")) {
            QuestData.setLevel(p, parseInt(val, 0, 2));
        } else if (name.equals("fogstrength")) {
            QuestData.setFogStrength(p, parseInt(val, 0, 100));
        } else {
            boolean on = val.equals("on") || val.equals("true") || val.equals("1");
            if (name.equals("fog")) QuestData.setOpt(p, "Fog", on);
            else if (name.equals("jumpscare")) QuestData.setOpt(p, "Jump", on);
            else if (name.equals("theft")) QuestData.setOpt(p, "Theft", on);
            else if (name.equals("signs")) QuestData.setOpt(p, "Signs", on);
            else if (name.equals("ambient")) QuestData.setOpt(p, "Ambient", on);
            else throw new WrongUsageException("/ss opt <fog|jumpscare|theft|signs|ambient|fogstrength|level> <on|off|0-100>");
        }
        HorrorDirector.sendOptions(p);                      // the options screen shows the new state
    }

    private void spawn(EntityPlayerMP p, String[] args) throws CommandException {
        if (args.length < 2) throw new WrongUsageException("/ss spawn <observing|stalking|disturbance|jumpscare|chase|rush>");
        String k = args[1].toLowerCase();
        PlayerHorror r = HorrorDirector.rec(p);
        if (k.equals("jumpscare")) { HorrorDirector.run(p, HorrorEvent.JUMPSCARE, true); return; }
        HorrorDirector.clearNull(p);
        NullState st;
        int life = 20 * 30;
        if (k.equals("observing")) st = NullState.OBSERVING;
        else if (k.equals("stalking")) st = NullState.STALKING;
        else if (k.equals("disturbance")) st = NullState.DISTURBANCE;
        else if (k.equals("chase") || k.equals("rush")) { st = NullState.CHASE; life = 0; }
        else throw new WrongUsageException("/ss spawn <observing|stalking|disturbance|jumpscare|chase|rush>");
        EntityNull n = SpawnHelper.spawn(p, r, st, 14, 24, life, false, 0.3F, st != NullState.CHASE);
        if (n == null) { say(p, "No valid spot found nearby - move to open ground and try again."); return; }
        if (k.equals("rush")) n.forceRush();
    }

    private static void say(EntityPlayerMP p, String s) { p.addChatMessage(new TextComponentString(s)); }

    private static ITextComponent button(String label, String cmd, TextFormatting color) {
        ITextComponent c = new TextComponentString("[" + label + "] ");
        c.getStyle().setColor(color).setClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, cmd));
        return c;
    }

    /** Clickable menu in chat (the Mod Options screen on key O is the nicer version). */
    private static void help(EntityPlayerMP p) {
        say(p, TextFormatting.DARK_RED + "== THE SPOILED SEED ==" + TextFormatting.RESET + "  (press O for Mod Options)");
        String[][] rows = {
            { "Jumpscare", "jumpscare", "Chase", "chase", "Stalk", "stalk", "Observe", "observe", "Glimpse", "glimpse" },
            { "Footsteps", "footsteps", "Knock", "knock", "Whisper", "whisper", "Sound", "sound", "Cave", "cave", "Sign", "sign" },
            { "Window", "window", "Mimic", "mimic", "Echo", "echo", "Blackout", "blackout" },
            { "Spawn rush", "spawn rush", "Spawn stalking", "spawn stalking", "Spawn chase", "spawn chase" },
            { "Torch", "torch", "Door", "door", "Theft", "theft", "Bed", "bed", "Remove Null", "clear" },
            { "Fog 40", "fog 40", "Fog 100", "fog 100", "Fog off", "fog off" },
            { "Status", "status", "Quest items", "give", "Guide", "guide", "Reset", "reset" } };
        for (String[] row : rows) {
            ITextComponent line = new TextComponentString("");
            for (int i = 0; i < row.length; i += 2) line.appendSibling(button(row[i], "/ss " + row[i + 1], TextFormatting.RED));
            p.addChatMessage(line);
        }
    }
}
