package com.spoiledseed.client;

import com.spoiledseed.registry.ModSounds;
import net.minecraft.client.Minecraft;
import net.minecraft.client.audio.ISound;
import net.minecraft.client.audio.PositionedSoundRecord;
import net.minecraft.client.audio.SoundHandler;
import net.minecraft.client.gui.GuiIngameMenu;
import net.minecraft.client.gui.GuiMainMenu;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.util.SoundCategory;
import net.minecraftforge.client.event.GuiOpenEvent;
import net.minecraftforge.client.event.GuiScreenEvent;
import net.minecraftforge.client.event.sound.PlaySoundEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;

/**
 * Replaces the vanilla title screen, plays the menu music, owns the custom key bindings
 * (Options > Controls > "The Spoiled Seed") and the pause-menu button.
 */
public class MenuHandler {
    public static final String CAT = "key.categories.spoiledseed";
    public static final KeyBinding KEY_OPTIONS = new KeyBinding("key.spoiledseed.options", Keyboard.KEY_O, CAT);
    public static final KeyBinding KEY_FOG = new KeyBinding("key.spoiledseed.fog", Keyboard.KEY_NONE, CAT);
    public static final KeyBinding KEY_JUMP = new KeyBinding("key.spoiledseed.jumpscare", Keyboard.KEY_NONE, CAT);
    public static final KeyBinding KEY_STATUS = new KeyBinding("key.spoiledseed.status", Keyboard.KEY_NONE, CAT);
    public static final KeyBinding KEY_GUIDE = new KeyBinding("key.spoiledseed.guide", Keyboard.KEY_NONE, CAT);
    public static final KeyBinding[] ALL_KEYS = { KEY_OPTIONS, KEY_FOG, KEY_JUMP, KEY_STATUS, KEY_GUIDE };

    private static final int PAUSE_BUTTON_ID = 9100;
    private ISound music;

    @SubscribeEvent
    public void onGuiOpen(GuiOpenEvent e) {
        if (e.getGui() instanceof GuiMainMenu) e.setGui(new GuiSpoiledMenu());
    }

    // ---- key bindings -----------------------------------------------------------------------
    @SubscribeEvent
    public void onKey(InputEvent.KeyInputEvent e) {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.theWorld == null || mc.thePlayer == null || mc.currentScreen != null) return;
        if (KEY_OPTIONS.isPressed()) mc.displayGuiScreen(new GuiModOptions(null));
        if (KEY_FOG.isPressed()) {
            boolean now = ClientFx.bit(0);
            ClientFx.options ^= 1;
            mc.thePlayer.sendChatMessage("/ss opt fog " + (now ? "off" : "on"));
        }
        if (KEY_JUMP.isPressed()) {
            boolean now = ClientFx.bit(1);
            ClientFx.options ^= 2;
            mc.thePlayer.sendChatMessage("/ss opt jumpscare " + (now ? "off" : "on"));
        }
        if (KEY_STATUS.isPressed()) mc.thePlayer.sendChatMessage("/ss status");
        if (KEY_GUIDE.isPressed()) mc.thePlayer.sendChatMessage("/ss guide");
    }

    // ---- menu music: ours replaces the vanilla title music ------------------------------------
    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getMinecraft();
        SoundHandler sh = mc.getSoundHandler();
        boolean wanted = ClientConfig.menuMusic && mc.theWorld == null && mc.currentScreen != null;
        if (wanted) {
            if (music == null || !sh.isSoundPlaying(music)) {
                music = PositionedSoundRecord.getMusicRecord(ModSounds.MUSIC_MENU);   // restarts when it ends = loop
                sh.playSound(music);
            }
        } else if (music != null) {
            sh.stopSound(music);
            music = null;
        }
    }

    @SubscribeEvent
    public void onPlaySound(PlaySoundEvent e) {
        if (!ClientConfig.menuMusic || Minecraft.getMinecraft().theWorld != null) return;
        ISound s = e.getSound();
        if (s != null && s.getCategory() == SoundCategory.MUSIC && "minecraft".equals(s.getSoundLocation().getResourceDomain())) {
            e.setResultSound(null);                                                  // no vanilla menu tune on top of ours
        }
    }

    // ---- pause menu button --------------------------------------------------------------------
    @SubscribeEvent
    public void onPauseInit(GuiScreenEvent.InitGuiEvent.Post e) {
        if (e.getGui() instanceof GuiIngameMenu) {
            e.getButtonList().add(new FlatButton(PAUSE_BUTTON_ID, 6, 6, 120, 20, "Spoiled Seed"));
        }
    }

    @SubscribeEvent
    public void onPauseAction(GuiScreenEvent.ActionPerformedEvent.Post e) {
        if (e.getGui() instanceof GuiIngameMenu && e.getButton().id == PAUSE_BUTTON_ID) {
            Minecraft.getMinecraft().displayGuiScreen(new GuiModOptions(e.getGui()));
        }
    }
}
