package com.spoiledseed.client;

import com.spoiledseed.SpoiledSeed;
import com.spoiledseed.entity.EntityNull;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.entity.layers.LayerRenderer;
import net.minecraft.util.ResourceLocation;

/** Herobrine-style glowing white eyes: additive, full-bright, visible through darkness and fog. */
public class LayerNullEyes implements LayerRenderer<EntityNull> {
    private static final ResourceLocation EYES = new ResourceLocation(SpoiledSeed.MODID, "textures/entity/null_eyes.png");
    private final RenderNull renderer;

    public LayerNullEyes(RenderNull renderer) { this.renderer = renderer; }

    @Override
    public void doRenderLayer(EntityNull e, float limbSwing, float limbSwingAmount, float partialTicks,
                              float age, float netHeadYaw, float headPitch, float scale) {
        float a = e.getAlpha();
        if (a < 0.02F) return;
        this.renderer.bindTexture(EYES);
        GlStateManager.enableBlend();
        GlStateManager.disableAlpha();
        GlStateManager.blendFunc(GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ONE);
        GlStateManager.depthMask(true);
        OpenGlHelper.setLightmapTextureCoords(OpenGlHelper.lightmapTexUnit, 240F, 240F);      // full brightness
        GlStateManager.color(a, a, a, 1F);
        GlStateManager.disableFog();                                                            // eyes shine through the Black Fog
        this.renderer.getMainModel().render(e, limbSwing, limbSwingAmount, age, netHeadYaw, headPitch, scale);
        GlStateManager.enableFog();

        int i = e.getBrightnessForRender(partialTicks);                                         // restore normal lighting
        OpenGlHelper.setLightmapTextureCoords(OpenGlHelper.lightmapTexUnit, (float) (i % 65536), (float) (i / 65536));
        GlStateManager.color(1F, 1F, 1F, 1F);
        GlStateManager.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA);
        GlStateManager.disableBlend();
        GlStateManager.enableAlpha();
    }

    @Override
    public boolean shouldCombineTextures() { return false; }
}
