package com.spoiledseed.registry;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;

public class ModTab {
    public static final CreativeTabs TAB = new CreativeTabs("spoiledseed") {
        @Override
        public Item getTabIconItem() {
            return ModItems.nullSeal;
        }
    };
}
