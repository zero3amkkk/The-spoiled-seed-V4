package com.spoiledseed.proxy;

import com.spoiledseed.client.ClientConfig;
import com.spoiledseed.client.ClientFx;
import com.spoiledseed.client.EndingHandler;
import com.spoiledseed.client.FogHandler;
import com.spoiledseed.client.HudHandler;
import com.spoiledseed.client.MenuHandler;
import com.spoiledseed.client.JumpscareHandler;
import com.spoiledseed.client.RenderNull;
import com.spoiledseed.entity.EntityNull;
import com.spoiledseed.registry.ModBlocks;
import com.spoiledseed.registry.ModItems;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.client.renderer.entity.RenderManager;
import java.io.File;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.item.Item;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.fml.client.registry.IRenderFactory;
import net.minecraftforge.fml.client.registry.RenderingRegistry;

public class ClientProxy extends CommonProxy {
    @Override
    public void preInit(File configDir) {
        ClientConfig.load(configDir);
        RenderingRegistry.registerEntityRenderingHandler(EntityNull.class, new IRenderFactory<EntityNull>() {
            @Override
            public Render<? super EntityNull> createRenderFor(RenderManager manager) {
                return new RenderNull(manager);
            }
        });
        model(ModItems.corruptedSample);
        model(ModItems.relicEcho);
        model(ModItems.relicCore);
        model(ModItems.relicSeal);
        model(ModItems.journalTorn);
        model(ModItems.journalAncient);
        model(ModItems.nullSeal);
        model(Item.getItemFromBlock(ModBlocks.ancientAltar));
        MinecraftForge.EVENT_BUS.register(new ClientFx());
        MinecraftForge.EVENT_BUS.register(new FogHandler());
        MinecraftForge.EVENT_BUS.register(new JumpscareHandler());
        MinecraftForge.EVENT_BUS.register(new EndingHandler());
        MinecraftForge.EVENT_BUS.register(new HudHandler());
        MinecraftForge.EVENT_BUS.register(new MenuHandler());
        for (KeyBinding k : MenuHandler.ALL_KEYS) ClientRegistry.registerKeyBinding(k);
    }

    private static void model(Item item) {
        ModelLoader.setCustomModelResourceLocation(item, 0, new ModelResourceLocation(item.getRegistryName(), "inventory"));
    }

    @Override
    public void handlePacket(final int type, final float value, final float value2) {
        Minecraft.getMinecraft().addScheduledTask(new Runnable() {
            @Override
            public void run() { ClientFx.handle(type, value, value2); }
        });
    }
}
