package com.spoiledseed.world;

import com.spoiledseed.config.ModConfig;
import com.spoiledseed.registry.ModBlocks;
import com.spoiledseed.registry.ModItems;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import net.minecraft.block.BlockLadder;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityChest;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.chunk.IChunkGenerator;
import net.minecraft.world.chunk.IChunkProvider;
import net.minecraftforge.fml.common.IWorldGenerator;

/**
 * ORGANIZED placement: the world is split into regions of N x N chunks (config). Every region holds EXACTLY
 *   3 Corrupted Sites (soul sand)   -> Corrupted Sample   (Quest 2)
 *   1 Echo Shrine (obsidian)        -> Echo Fragment      (Quest 4)
 *   1 Core Cairn (netherrack)       -> Corrupted Core     (Quest 4)
 *   1 Forgotten Ruin (mossy, ladder to an underground chamber) -> Ancient Journal + Forgotten Seal + Ancient Altar (Quests 3-5)
 * Positions are derived from the world seed, so they are stable and /ss locate can find them.
 * Every structure is built inside ONE chunk (no cross-chunk generation problems).
 */
public class StructureGenerator implements IWorldGenerator {
    public enum Kind { SITE, SHRINE, CAIRN, RUIN }

    public static class Slot {
        public final Kind kind;
        public final int chunkX, chunkZ, offX, offZ;
        Slot(Kind k, int cx, int cz, int ox, int oz) { kind = k; chunkX = cx; chunkZ = cz; offX = ox; offZ = oz; }
        public int blockX() { return chunkX * 16 + offX; }
        public int blockZ() { return chunkZ * 16 + offZ; }
    }

    private static final Kind[] LAYOUT = { Kind.SITE, Kind.SITE, Kind.SITE, Kind.SHRINE, Kind.CAIRN, Kind.RUIN };

    public static List<Slot> slots(long seed, int rx, int rz) {
        int n = ModConfig.structureRegionChunks;
        Random r = new Random(seed ^ (rx * 341873128712L) ^ (rz * 132897987541L) ^ 0x5EEDL);
        List<Slot> out = new ArrayList<Slot>();
        for (Kind k : LAYOUT) {
            int lx = 0, lz = 0;
            for (int attempt = 0; attempt < 60; attempt++) {
                lx = r.nextInt(n);
                lz = r.nextInt(n);
                boolean ok = true;
                for (Slot s : out) {                       // keep structures at least 2 chunks apart
                    if (Math.abs(s.chunkX - (rx * n + lx)) + Math.abs(s.chunkZ - (rz * n + lz)) < 3) { ok = false; break; }
                }
                if (ok) break;
            }
            out.add(new Slot(k, rx * n + lx, rz * n + lz, 8 + r.nextInt(3), 8 + r.nextInt(3)));
        }
        return out;
    }

    /** Nearest planned structure of a kind (it may not be generated yet). */
    public static Slot locate(World w, BlockPos from, Kind kind) {
        int n = ModConfig.structureRegionChunks;
        int rx0 = Math.floorDiv(from.getX() >> 4, n), rz0 = Math.floorDiv(from.getZ() >> 4, n);
        Slot best = null;
        double bestD = Double.MAX_VALUE;
        for (int dx = -2; dx <= 2; dx++)
            for (int dz = -2; dz <= 2; dz++)
                for (Slot s : slots(w.getSeed(), rx0 + dx, rz0 + dz)) {
                    if (s.kind != kind) continue;
                    double d = Math.pow(s.blockX() - from.getX(), 2) + Math.pow(s.blockZ() - from.getZ(), 2);
                    if (d < bestD) { bestD = d; best = s; }
                }
        return best;
    }

    @Override
    public void generate(Random rand, int chunkX, int chunkZ, World world, IChunkGenerator gen, IChunkProvider prov) {
        if (!ModConfig.structuresEnabled || world.provider.getDimension() != 0) return;
        int n = ModConfig.structureRegionChunks;
        for (Slot s : slots(world.getSeed(), Math.floorDiv(chunkX, n), Math.floorDiv(chunkZ, n))) {
            if (s.chunkX == chunkX && s.chunkZ == chunkZ) build(world, s, rand);
        }
    }

    // ---- building ------------------------------------------------------------------------
    private static void build(World w, Slot s, Random rand) {
        BlockPos g = w.getHeight(new BlockPos(s.blockX(), 0, s.blockZ()));
        while (g.getY() > 2 && (w.isAirBlock(g.down()) || isFoliage(w.getBlockState(g.down())))) g = g.down();
        if (!w.getBlockState(g.down()).getMaterial().isSolid()) return;     // never on water / lava

        switch (s.kind) {
            case SITE:
                platform(w, g, Blocks.SOUL_SAND.getDefaultState(), Blocks.MOSSY_COBBLESTONE.getDefaultState(),
                        new ItemStack(ModItems.corruptedSample), new ItemStack(Blocks.TORCH, 2 + rand.nextInt(3)));
                break;
            case SHRINE:
                platform(w, g, Blocks.OBSIDIAN.getDefaultState(), Blocks.STONEBRICK.getDefaultState(),
                        new ItemStack(ModItems.relicEcho), new ItemStack(Items.BREAD, 2 + rand.nextInt(3)));
                break;
            case CAIRN:
                platform(w, g, Blocks.NETHERRACK.getDefaultState(), Blocks.COBBLESTONE.getDefaultState(),
                        new ItemStack(ModItems.relicCore), new ItemStack(Items.COAL, 3 + rand.nextInt(4)));
                break;
            case RUIN:
                ruin(w, g);
                break;
        }
    }

    private static boolean isFoliage(IBlockState s) {
        Material m = s.getMaterial();
        return m == Material.LEAVES || m == Material.PLANTS || m == Material.VINE;
    }

    /** Fixed chest layout: main loot in the middle slot (13), bonus supplies on its left (12) / right (14). */
    private static void fillChest(World w, BlockPos chest, ItemStack left, ItemStack middle, ItemStack right) {
        TileEntity te = w.getTileEntity(chest);
        if (!(te instanceof TileEntityChest)) return;
        TileEntityChest c = (TileEntityChest) te;
        if (left != null) c.setInventorySlotContents(12, left);
        if (middle != null) c.setInventorySlotContents(13, middle);
        if (right != null) c.setInventorySlotContents(14, right);
    }

    /** 5x5 floor, four pillars, a chest in the middle, clear sky above. */
    private static void platform(World w, BlockPos g, IBlockState floor, IBlockState pillar, ItemStack main, ItemStack bonus) {
        IBlockState air = Blocks.AIR.getDefaultState();
        for (int dx = -2; dx <= 2; dx++)
            for (int dz = -2; dz <= 2; dz++) {
                w.setBlockState(g.add(dx, -1, dz), floor, 2);
                for (int dy = 0; dy < 5; dy++) w.setBlockState(g.add(dx, dy, dz), air, 2);
            }
        for (int sx = -2; sx <= 2; sx += 4)
            for (int sz = -2; sz <= 2; sz += 4)
                for (int dy = 0; dy < 3; dy++) w.setBlockState(g.add(sx, dy, sz), pillar, 2);
        if (main != null) {
            w.setBlockState(g, Blocks.CHEST.getDefaultState(), 2);
            fillChest(w, g, null, main, bonus);
        } else {
            w.setBlockState(g, pillar, 2);
        }
    }

    private static void ruin(World w, BlockPos g) {
        IBlockState brick = Blocks.STONEBRICK.getDefaultState();
        IBlockState air = Blocks.AIR.getDefaultState();
        IBlockState ladder = Blocks.LADDER.getDefaultState().withProperty(BlockLadder.FACING, EnumFacing.NORTH);
        int y0 = Math.max(8, Math.min(22, g.getY() - 10));
        if (g.getY() - y0 < 7) return;                                       // not enough ground above

        // marker on the surface: mossy platform, no chest (the loot is underground)
        platform(w, g, Blocks.MOSSY_COBBLESTONE.getDefaultState(), Blocks.MOSSY_COBBLESTONE.getDefaultState(), null, null);

        // chamber 7x4x7: stone-brick shell, hollow inside
        for (int dx = -3; dx <= 3; dx++)
            for (int dz = -3; dz <= 3; dz++)
                for (int dy = 0; dy <= 4; dy++) {
                    boolean edge = dx == -3 || dx == 3 || dz == -3 || dz == 3 || dy == 0 || dy == 4;
                    w.setBlockState(new BlockPos(g.getX() + dx, y0 + dy, g.getZ() + dz), edge ? brick : air, 2);
                }
        // ladder shaft at (0,+2), hanging on the wall block behind it (z+3)
        int lx = g.getX(), lz = g.getZ() + 2;
        for (int y = y0 + 1; y <= g.getY() - 1; y++) {
            w.setBlockState(new BlockPos(lx, y, lz), ladder, 2);
            w.setBlockState(new BlockPos(lx, y, lz + 1), brick, 2);
        }
        // contents: chest (journal | torches | seal), the altar, torches
        BlockPos chest = new BlockPos(g.getX() - 2, y0 + 1, g.getZ() - 2);
        w.setBlockState(chest, Blocks.CHEST.getDefaultState(), 2);
        fillChest(w, chest, new ItemStack(ModItems.journalAncient), new ItemStack(Blocks.TORCH, 4), new ItemStack(ModItems.relicSeal));
        w.setBlockState(new BlockPos(g.getX(), y0 + 1, g.getZ() - 1), ModBlocks.ancientAltar.getDefaultState(), 2);
        w.setBlockState(new BlockPos(g.getX() + 2, y0 + 1, g.getZ() - 2), Blocks.TORCH.getDefaultState(), 2);
        w.setBlockState(new BlockPos(g.getX() - 2, y0 + 1, g.getZ() + 2), Blocks.TORCH.getDefaultState(), 2);
    }
}
