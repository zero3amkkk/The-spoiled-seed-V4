package com.spoiledseed.horror;

import com.spoiledseed.config.ModConfig;
import com.spoiledseed.quest.QuestData;
import java.util.Random;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.event.world.BlockEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

/** Block events: remembers chests the player placed (for theft), springs sign traps, cave-running while mining ore. */
public class TrapEvents {
    private static final Random RAND = new Random();

    @SubscribeEvent
    public void onPlace(BlockEvent.PlaceEvent e) {
        EntityPlayer p = e.getPlayer();
        if (p == null || e.getWorld().isRemote) return;
        IBlockState s = e.getPlacedBlock();
        if (s.getBlock() == Blocks.CHEST || s.getBlock() == Blocks.TRAPPED_CHEST) {
            QuestData.addPos(p, WorldPranks.CHEST_KEY, e.getPos(), 64);
        }
    }

    @SubscribeEvent
    public void onBreak(BlockEvent.BreakEvent e) {
        EntityPlayer pl = e.getPlayer();
        if (!(pl instanceof EntityPlayerMP) || e.getWorld().isRemote) return;
        EntityPlayerMP p = (EntityPlayerMP) pl;
        BlockPos pos = e.getPos();

        if (SignTrap.isCursed(p, pos)) { SignTrap.onBroken(p, pos); return; }
        QuestData.removePos(p, WorldPranks.CHEST_KEY, pos);

        // cave mining: ores underground, no sky above
        IBlockState s = e.getState();
        if (QuestData.isSealed(p) || p.capabilities.isCreativeMode || p.dimension != 0) return;
        if (pos.getY() >= 55 || e.getWorld().canSeeSky(pos)) return;
        if (s.getBlock().getRegistryName() == null || !s.getBlock().getRegistryName().getResourcePath().contains("ore")) return;
        PlayerHorror r = HorrorDirector.rec(p);
        if (r.caveCd > 0) return;
        float chance = ModConfig.caveRunChance * (1F + QuestData.getThreat(p) * 0.1F);
        if (RAND.nextFloat() < chance) {
            r.caveCd = 120;
            WorldPranks.caveRun(p);
        }
    }
}
