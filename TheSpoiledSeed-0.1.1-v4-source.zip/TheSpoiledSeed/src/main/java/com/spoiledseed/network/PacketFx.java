package com.spoiledseed.network;

import com.spoiledseed.SpoiledSeed;
import io.netty.buffer.ByteBuf;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;

/**
 * Server -> client. FOG: strength 0..1 | JUMPSCARE: variant 0..2 | ENDING |
 * CHASE_DIST: blocks to The Null (negative = no chase) | OPTIONS: option bit mask |
 * STATS: value = stage + 16 * threat, value2 = minutes played.
 */
public class PacketFx implements IMessage {
    public static final int FOG = 0;
    public static final int JUMPSCARE = 1;
    public static final int ENDING = 2;
    public static final int CHASE_DIST = 3;
    public static final int OPTIONS = 4;
    public static final int STATS = 5;

    public int type;
    public float value;
    public float value2;

    public PacketFx() {}
    public PacketFx(int type, float value) { this(type, value, 0F); }
    public PacketFx(int type, float value, float value2) { this.type = type; this.value = value; this.value2 = value2; }

    @Override
    public void fromBytes(ByteBuf buf) { type = buf.readInt(); value = buf.readFloat(); value2 = buf.readFloat(); }

    @Override
    public void toBytes(ByteBuf buf) { buf.writeInt(type); buf.writeFloat(value); buf.writeFloat(value2); }

    public static class Handler implements IMessageHandler<PacketFx, IMessage> {
        @Override
        public IMessage onMessage(PacketFx m, MessageContext ctx) {
            SpoiledSeed.proxy.handlePacket(m.type, m.value, m.value2);
            return null;
        }
    }
}
