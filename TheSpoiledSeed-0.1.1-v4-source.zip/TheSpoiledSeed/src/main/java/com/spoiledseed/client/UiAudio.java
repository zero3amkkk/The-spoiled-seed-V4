package com.spoiledseed.client;

import com.spoiledseed.registry.ModSounds;
import net.minecraft.client.Minecraft;
import net.minecraft.client.audio.PositionedSoundRecord;

/** Hover / click sounds for the mod's screens. */
public class UiAudio {
    public static void hover() {
        if (ClientConfig.uiSounds) Minecraft.getMinecraft().getSoundHandler().playSound(PositionedSoundRecord.getMasterRecord(ModSounds.UI_HOVER, 1.0F));
    }

    public static void click() {
        if (ClientConfig.uiSounds) Minecraft.getMinecraft().getSoundHandler().playSound(PositionedSoundRecord.getMasterRecord(ModSounds.UI_CLICK, 1.0F));
    }
}
