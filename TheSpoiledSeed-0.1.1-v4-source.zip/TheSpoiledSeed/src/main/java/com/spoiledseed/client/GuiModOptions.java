package com.spoiledseed.client;

import java.io.IOException;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiControls;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.client.settings.KeyBinding;

/**
 * Mod Options (key O, rebindable; or the "Spoiled Seed" button in the pause menu).
 * Categories: Horror, Fog, Audio & UI, Progress, Controls, Tools.
 * Horror and Fog settings are stored per player on the server (through /ss opt ...); Audio & UI are client settings.
 */
public class GuiModOptions extends GuiScreen {
    private static final String[] CATS = { "Horror", "Fog", "Audio & UI", "Progress", "Controls", "Tools" };
    private static final String[] LEVELS = { "LOW", "NORMAL", "HIGH" };
    private static final String[] QUESTS = { "The First Sighting", "The Black Fog", "The Forgotten Place", "The Three Relics", "The Final Ritual" };
    private static final String[] TOOL_PAGES = { "Monster", "Events", "Sounds", "Quest" };

    /** { label, command, closeScreenAfter } for each Tools page. */
    private static final String[][][] TOOLS = {
        { { "Observe", "/ss spawn observing", "1" }, { "Stalk", "/ss spawn stalking", "1" }, { "Disturbance", "/ss spawn disturbance", "1" },
          { "Chase", "/ss spawn chase", "1" }, { "Rush (charge)", "/ss spawn rush", "1" }, { "Jumpscare", "/ss jumpscare", "1" },
          { "Glimpse", "/ss glimpse", "1" }, { "Near my bed", "/ss bed", "1" }, { "Remove Null", "/ss clear", "0" } },
        { { "Footsteps", "/ss footsteps", "1" }, { "Echo steps", "/ss echo", "1" }, { "Knock", "/ss knock", "1" },
          { "Whisper", "/ss whisper", "1" }, { "Distant sound", "/ss sound", "1" }, { "Cave run", "/ss cave", "1" },
          { "Window peek", "/ss window", "1" }, { "Mimic chat", "/ss mimic", "1" }, { "Cursed sign", "/ss sign", "1" },
          { "Torches out", "/ss torch", "1" }, { "Blackout", "/ss blackout", "1" }, { "Door", "/ss door", "1" },
          { "Chest theft", "/ss theft", "1" } },
        { { "Jumpscare", "/ss play jumpscare", "0" }, { "Heartbeat", "/ss play heartbeat", "0" }, { "Whisper", "/ss play whisper", "0" },
          { "Breath", "/ss play breath", "0" }, { "Knock", "/ss play knock", "0" }, { "Scrape", "/ss play scrape", "0" },
          { "Window tap", "/ss play tap", "0" }, { "Creak", "/ss play creak", "0" }, { "Sting", "/ss play sting", "0" },
          { "Footstep", "/ss play footstep", "0" }, { "Chase step", "/ss play chase", "0" }, { "Vanish", "/ss play vanish", "0" },
          { "Drone", "/ss play drone", "0" }, { "Seal", "/ss play seal", "0" } },
        { { "Status", "/ss status", "1" }, { "Locate Site", "/ss locate site", "1" }, { "Locate Shrine", "/ss locate shrine", "1" },
          { "Locate Cairn", "/ss locate cairn", "1" }, { "Locate Ruin", "/ss locate ruin", "1" }, { "Quest items", "/ss give", "1" },
          { "New guide book", "/ss guide", "1" }, { "Stage 0", "/ss stage 0", "0" }, { "Stage 4", "/ss stage 4", "0" },
          { "Threat 0", "/ss threat 0", "0" }, { "Threat 12", "/ss threat 12", "0" }, { "Reset progress", "/ss reset", "0" } }
    };

    private final GuiScreen parent;
    private int cat = 0, toolPage = 0;
    private SliderButton fogSlider;

    public GuiModOptions(GuiScreen parent) { this.parent = parent; }

    private int x0() { return this.width / 2 - 190; }
    private int top() { return Math.max(8, this.height / 2 - 112); }

    // ---- layout ---------------------------------------------------------------------------
    @Override
    public void initGui() {
        this.buttonList.clear();
        this.fogSlider = null;
        int x0 = x0(), top = top();
        for (int i = 0; i < CATS.length; i++) {
            FlatButton b = new FlatButton(100 + i, x0, top + 30 + i * 24, 92, 20, CATS[i]);
            b.selected = (i == cat);
            this.buttonList.add(b);
        }
        int cx = x0 + 102, cw = 278, y = top + 30;
        switch (cat) {
            case 0:
                toggle(1, cx, y, cw, "Jumpscares", ClientFx.bit(1));
                toggle(2, cx, y + 24, cw, "Chest theft (your chests only)", ClientFx.bit(2));
                toggle(3, cx, y + 48, cw, "Cursed signs", ClientFx.bit(3));
                toggle(4, cx, y + 72, cw, "Ambient scares at night", ClientFx.bit(6));
                this.buttonList.add(new FlatButton(5, cx, y + 96, cw, 20, "Horror level: " + LEVELS[Math.min(2, ClientFx.level())]));
                break;
            case 1:
                toggle(10, cx, y, cw, "Black Fog", ClientFx.bit(0));
                this.fogSlider = new SliderButton(11, cx, y + 24, cw, 20, "Fog strength", ClientFx.fogStrength());
                this.buttonList.add(this.fogSlider);
                this.buttonList.add(new FlatButton(12, cx, y + 52, cw / 2 - 2, 20, "Preview 60%"));
                this.buttonList.add(new FlatButton(13, cx + cw / 2 + 2, y + 52, cw / 2 - 2, 20, "Back to automatic"));
                break;
            case 2:
                toggle(20, cx, y, cw, "UI sounds", ClientConfig.uiSounds);
                toggle(21, cx, y + 24, cw, "Menu music", ClientConfig.menuMusic);
                toggle(22, cx, y + 48, cw, "Reduce flashing (accessibility)", ClientConfig.reduceFlash);
                toggle(23, cx, y + 72, cw, "Camera shake", ClientConfig.screenShake);
                toggle(24, cx, y + 96, cw, "Chase distance HUD", ClientConfig.chaseHud);
                break;
            case 3:
                this.buttonList.add(new FlatButton(30, cx, y + 120, cw / 2 - 2, 20, "Locate Site"));
                this.buttonList.add(new FlatButton(31, cx + cw / 2 + 2, y + 120, cw / 2 - 2, 20, "Locate Shrine"));
                this.buttonList.add(new FlatButton(32, cx, y + 144, cw / 2 - 2, 20, "Locate Cairn"));
                this.buttonList.add(new FlatButton(33, cx + cw / 2 + 2, y + 144, cw / 2 - 2, 20, "Locate Ruin"));
                break;
            case 4:
                this.buttonList.add(new FlatButton(40, cx, y + KeyCount.ROWS * 14 + 8, cw, 20, "Open Controls (rebind keys)"));
                break;
            case 5:
                this.buttonList.add(new FlatButton(49, cx, y, cw, 20, "Page: " + TOOL_PAGES[toolPage] + "  (click for next)"));
                String[][] spec = TOOLS[toolPage];
                int cols = 3, bw = (cw - 4) / cols;
                for (int i = 0; i < spec.length; i++) {
                    this.buttonList.add(new FlatButton(50 + i, cx + (i % cols) * (bw + 2), y + 26 + (i / cols) * 22, bw, 20, spec[i][0]));
                }
                break;
            default:
                break;
        }
        this.buttonList.add(new FlatButton(99, this.width / 2 - 50, top + 232, 100, 20, "Close"));
    }

    private static class KeyCount { static final int ROWS = MenuHandler.ALL_KEYS.length; }

    private void toggle(int id, int x, int y, int w, String label, boolean on) {
        this.buttonList.add(new FlatButton(id, x, y, w, 20, label + ": " + (on ? "ON" : "OFF")));
    }

    private void send(String cmd) {
        if (this.mc.thePlayer != null) this.mc.thePlayer.sendChatMessage(cmd);
    }

    /** Server-side option: update the local copy right away, then tell the server (it confirms with a packet). */
    private void flip(int bitIndex, String name) {
        boolean now = ClientFx.bit(bitIndex);
        ClientFx.options ^= (1 << bitIndex);
        send("/ss opt " + name + " " + (now ? "off" : "on"));
        initGui();
    }

    // ---- actions --------------------------------------------------------------------------
    @Override
    protected void actionPerformed(GuiButton b) throws IOException {
        int id = b.id;
        if (id == 99) { this.mc.displayGuiScreen(this.parent); return; }
        if (id >= 100) { cat = id - 100; initGui(); return; }

        switch (cat) {
            case 0:
                if (id == 1) flip(1, "jumpscare");
                else if (id == 2) flip(2, "theft");
                else if (id == 3) flip(3, "signs");
                else if (id == 4) flip(6, "ambient");
                else if (id == 5) {
                    int level = (ClientFx.level() + 1) % 3;
                    ClientFx.options = (ClientFx.options & ~(3 << 4)) | (level << 4);
                    send("/ss opt level " + level);
                    initGui();
                }
                break;
            case 1:
                if (id == 10) flip(0, "fog");
                else if (id == 12) send("/ss fog 60");
                else if (id == 13) send("/ss fog off");
                break;
            case 2:
                if (id == 20) ClientConfig.uiSounds = !ClientConfig.uiSounds;
                else if (id == 21) ClientConfig.menuMusic = !ClientConfig.menuMusic;
                else if (id == 22) ClientConfig.reduceFlash = !ClientConfig.reduceFlash;
                else if (id == 23) ClientConfig.screenShake = !ClientConfig.screenShake;
                else if (id == 24) ClientConfig.chaseHud = !ClientConfig.chaseHud;
                ClientConfig.save();
                initGui();
                break;
            case 3:
                if (id >= 30 && id <= 33) {
                    this.mc.displayGuiScreen(null);
                    send("/ss locate " + new String[] { "site", "shrine", "cairn", "ruin" }[id - 30]);
                }
                break;
            case 4:
                if (id == 40) this.mc.displayGuiScreen(new GuiControls(this, this.mc.gameSettings));
                break;
            case 5:
                if (id == 49) { toolPage = (toolPage + 1) % TOOLS.length; initGui(); }
                else if (id >= 50) {
                    String[] s = TOOLS[toolPage][id - 50];
                    if ("1".equals(s[2])) this.mc.displayGuiScreen(null);
                    send(s[1]);
                }
                break;
            default:
                break;
        }
    }

    @Override
    protected void mouseReleased(int mouseX, int mouseY, int state) {
        boolean wasDragging = this.fogSlider != null && this.fogSlider.dragging;
        super.mouseReleased(mouseX, mouseY, state);
        if (wasDragging) {
            int v = this.fogSlider.value;
            ClientFx.options = (ClientFx.options & ~(127 << 8)) | (v << 8);
            send("/ss opt fogstrength " + v);
        }
    }

    // ---- drawing --------------------------------------------------------------------------
    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        this.drawDefaultBackground();
        int x0 = x0(), top = top();
        Gui.drawRect(x0 - 10, top - 8, x0 + 390, top + 262, 0xB0000000);
        Gui.drawRect(x0 + 96, top + 26, x0 + 97, top + 226, 0x40FFFFFF);          // divider

        GlStateManager.pushMatrix();
        GlStateManager.translate(this.width / 2F, top + 2F, 0F);
        GlStateManager.scale(1.6F, 1.6F, 1F);
        this.drawCenteredString(this.fontRendererObj, "THE SPOILED SEED  -  MOD OPTIONS", 0, 0, 0xC8C8C8);
        GlStateManager.popMatrix();

        int cx = x0 + 102, y = top + 30;
        if (cat == 0) {
            this.drawString(this.fontRendererObj, "Stored per player. Level scales how often it comes.", cx, y + 124, 0x707070);
            this.drawString(this.fontRendererObj, "Night, your bed and ritual items raise it further.", cx, y + 136, 0x707070);
        } else if (cat == 1) {
            this.drawString(this.fontRendererObj, "The fog is there from the moment you spawn.", cx, y + 80, 0x707070);
            this.drawString(this.fontRendererObj, "Strength scales every kind of fog. 0% = clear.", cx, y + 92, 0x707070);
        } else if (cat == 2) {
            this.drawString(this.fontRendererObj, "Music volume: Options > Music & Sounds.", cx, y + 124, 0x707070);
        } else if (cat == 3) {
            drawProgress(cx, y);
        } else if (cat == 4) {
            drawControls(cx, y);
        } else if (cat == 5) {
            this.drawString(this.fontRendererObj, "No cooldowns. (/ss needs op if openCommands=false)", cx, y + 26 + 22 * (TOOLS[toolPage].length / 3 + 1), 0x707070);
        }
        super.drawScreen(mouseX, mouseY, partialTicks);
    }

    private void drawProgress(int cx, int y) {
        for (int i = 0; i < QUESTS.length; i++) {
            boolean done = i < ClientFx.stage, now = i == ClientFx.stage;
            String mark = done ? "[x] " : now ? "[>] " : "[ ] ";
            int color = done ? 0x55FF55 : now ? 0xFFDD55 : 0x777777;
            this.drawString(this.fontRendererObj, mark + (i + 1) + ". " + QUESTS[i], cx, y + i * 12, color);
        }
        int t = ClientFx.threat;
        this.drawString(this.fontRendererObj, "Threat: " + t + " / 12", cx, y + 68, t >= 8 ? 0xFF5555 : t >= 4 ? 0xFFAA55 : 0xCCCCCC);
        Gui.drawRect(cx, y + 80, cx + 200, y + 86, 0x90000000);
        Gui.drawRect(cx, y + 80, cx + 200 * t / 12, y + 86, t >= 8 ? 0xFFCC2222 : 0xFFB0B0B0);
        this.drawString(this.fontRendererObj, "Play time: " + (int) (ClientFx.minutes / 60) + " h " + ((int) ClientFx.minutes % 60) + " min", cx, y + 94, 0xB0B0B0);
        this.drawString(this.fontRendererObj, "Every ritual item you find raises the threat.", cx, y + 106, 0x707070);
    }

    private void drawControls(int cx, int y) {
        for (int i = 0; i < MenuHandler.ALL_KEYS.length; i++) {
            KeyBinding k = MenuHandler.ALL_KEYS[i];
            String key = k.getKeyCode() == 0 ? "not bound" : GameSettings.getKeyDisplayString(k.getKeyCode());
            this.drawString(this.fontRendererObj, net.minecraft.client.resources.I18n.format(k.getKeyDescription()), cx, y + i * 14, 0xD0D0D0);
            this.drawString(this.fontRendererObj, "[" + key + "]", cx + 190, y + i * 14, k.getKeyCode() == 0 ? 0x777777 : 0xFFDD55);
        }
    }

    @Override
    public boolean doesGuiPauseGame() { return false; }
}
