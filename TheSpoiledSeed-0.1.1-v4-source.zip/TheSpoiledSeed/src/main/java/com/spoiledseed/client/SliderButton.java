package com.spoiledseed.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.audio.SoundHandler;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiButton;

/** Horizontal slider 0..100 in the same flat style. The screen commits the value when the mouse is released. */
public class SliderButton extends GuiButton {
    public int value;                 // 0..100
    public boolean dragging;
    private final String label;

    public SliderButton(int id, int x, int y, int w, int h, String label, int value) {
        super(id, x, y, w, h, label + ": " + value + "%");
        this.label = label;
        this.value = value;
    }

    @Override
    public void drawButton(Minecraft mc, int mouseX, int mouseY) {
        if (!this.visible) return;
        this.hovered = mouseX >= this.xPosition && mouseY >= this.yPosition
                && mouseX < this.xPosition + this.width && mouseY < this.yPosition + this.height;
        if (this.dragging) {
            this.value = Math.max(0, Math.min(100, Math.round((mouseX - this.xPosition) * 100F / this.width)));
            this.displayString = this.label + ": " + this.value + "%";
        }
        Gui.drawRect(this.xPosition, this.yPosition, this.xPosition + this.width, this.yPosition + this.height, this.hovered ? 0x70202020 : 0x50080808);
        int fill = this.xPosition + Math.round(this.width * this.value / 100F);
        Gui.drawRect(this.xPosition, this.yPosition + this.height - 3, fill, this.yPosition + this.height, 0xFFB0B0B0);
        this.drawCenteredString(mc.fontRendererObj, this.displayString, this.xPosition + this.width / 2,
                this.yPosition + (this.height - 8) / 2 - 1, this.hovered || this.dragging ? 0xFFFFFF : 0x9A9A9A);
    }

    @Override
    public boolean mousePressed(Minecraft mc, int mouseX, int mouseY) {
        boolean hit = super.mousePressed(mc, mouseX, mouseY);
        if (hit) this.dragging = true;
        return hit;
    }

    @Override
    public void mouseReleased(int mouseX, int mouseY) {
        this.dragging = false;
    }

    @Override
    public void playPressSound(SoundHandler handler) {
        UiAudio.click();
    }
}
