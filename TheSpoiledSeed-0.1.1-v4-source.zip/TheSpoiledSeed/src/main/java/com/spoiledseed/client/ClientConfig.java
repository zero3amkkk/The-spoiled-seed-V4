package com.spoiledseed.client;

import java.io.File;
import net.minecraftforge.common.config.Configuration;

/** Client-only preferences (config/spoiledseed-client.cfg). Edited from the Mod Options screen. */
public class ClientConfig {
    public static boolean uiSounds = true;
    public static boolean menuMusic = true;
    public static boolean reduceFlash = false;
    public static boolean screenShake = true;
    public static boolean chaseHud = true;

    private static Configuration cfg;
    private static final String C = "client";

    public static void load(File dir) {
        cfg = new Configuration(new File(dir, "spoiledseed-client.cfg"));
        read();
    }

    private static void read() {
        uiSounds = cfg.get(C, "uiSounds", true, "Hover and click sounds in the mod's menus.").getBoolean();
        menuMusic = cfg.get(C, "menuMusic", true, "Play the mod's sad title music (replaces the vanilla menu music).").getBoolean();
        reduceFlash = cfg.get(C, "reduceFlash", false, "Accessibility: no white flash, softer jumpscare effects.").getBoolean();
        screenShake = cfg.get(C, "screenShake", true, "Camera shake during jumpscares.").getBoolean();
        chaseHud = cfg.get(C, "chaseHud", true, "Show the distance to The Null above your hearts while it hunts you.").getBoolean();
        if (cfg.hasChanged()) cfg.save();
    }

    public static void save() {
        if (cfg == null) return;
        cfg.get(C, "uiSounds", true).set(uiSounds);
        cfg.get(C, "menuMusic", true).set(menuMusic);
        cfg.get(C, "reduceFlash", false).set(reduceFlash);
        cfg.get(C, "screenShake", true).set(screenShake);
        cfg.get(C, "chaseHud", true).set(chaseHud);
        cfg.save();
    }
}
