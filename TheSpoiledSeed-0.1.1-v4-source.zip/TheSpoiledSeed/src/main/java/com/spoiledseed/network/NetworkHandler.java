package com.spoiledseed.network;

import com.spoiledseed.SpoiledSeed;
import net.minecraftforge.fml.common.network.NetworkRegistry;
import net.minecraftforge.fml.common.network.simpleimpl.SimpleNetworkWrapper;
import net.minecraftforge.fml.relauncher.Side;

public class NetworkHandler {
    public static SimpleNetworkWrapper CHANNEL;

    public static void init() {
        CHANNEL = NetworkRegistry.INSTANCE.newSimpleChannel(SpoiledSeed.MODID);
        CHANNEL.registerMessage(PacketFx.Handler.class, PacketFx.class, 0, Side.CLIENT);
    }
}
