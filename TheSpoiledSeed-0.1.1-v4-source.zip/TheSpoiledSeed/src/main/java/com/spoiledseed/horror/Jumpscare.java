package com.spoiledseed.horror;

import com.spoiledseed.config.ModConfig;
import com.spoiledseed.entity.NullState;
import com.spoiledseed.network.NetworkHandler;
import com.spoiledseed.network.PacketFx;
import com.spoiledseed.quest.QuestData;
import com.spoiledseed.registry.ModSounds;
import java.util.Random;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.MobEffects;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.WorldServer;

/**
 * Jumpscare sequence (unpredictable):
 *  1. dread cue (heartbeat) and a random delay of 0.5 - 3 s (sometimes none at all)
 *  2. The Null appears right in front of the player, "TPS S" scream plays
 *  3. client: white flash, shaking camera, giant glowing-eye face, static; server: short blindness
 *  4. aftermath: whisper, fog, and a long cooldown
 */
public class Jumpscare {
    private static final Random RAND = new Random();

    public static void trigger(final EntityPlayerMP p, final PlayerHorror r, boolean force) {
        if (!force) {
            if (!ModConfig.jumpscareEnabled || !QuestData.optJump(p)) return;
            if (r.jumpCd > 0) { HorrorDirector.run(p, HorrorEvent.GLIMPSE, false); return; }
        }
        r.jumpCd = ModConfig.jumpscareCooldownSeconds + RAND.nextInt(Math.max(1, ModConfig.jumpscareCooldownSeconds / 2));
        final int variant = RAND.nextInt(3);
        int delay = 0;
        if (!force && RAND.nextInt(4) != 0) {
            delay = 10 + RAND.nextInt(50);
            p.worldObj.playSound(null, p.posX, p.posY, p.posZ, ModSounds.HEARTBEAT, SoundCategory.HOSTILE, 1.0F, 1.0F);
        }
        if (delay <= 0) fire(p, r, variant);
        else Scheduler.schedule(delay, new Runnable() { @Override public void run() { fire(p, r, variant); } });
    }

    public static void fire(final EntityPlayerMP p, final PlayerHorror r, int variant) {
        if (p.isDead) return;
        WorldServer w = (WorldServer) p.worldObj;

        // the monster: right in front, very close (variant decides distance and side)
        Vec3d look = p.getLookVec();
        double fx = look.xCoord, fz = look.zCoord, l = Math.sqrt(fx * fx + fz * fz);
        if (l < 0.01D) { fx = 0D; fz = 1D; l = 1D; }
        fx /= l; fz /= l;
        double dist = variant == 1 ? 1.7D : 2.5D;
        double side = variant == 2 ? 1.1D : 0D;
        if (HorrorDirector.findNull(w, r) == null) {
            for (double d = dist; d >= 1.2D; d -= 0.4D) {
                BlockPos bp = new BlockPos(p.posX + fx * d - fz * side, p.posY, p.posZ + fz * d + fx * side);
                if (w.isAirBlock(bp) && w.isAirBlock(bp.up())) { SpawnHelper.spawnAt(p, r, bp, NullState.JUMPSCARE, 40, false, 0F); break; }
            }
        }

        w.playSound(null, p.posX, p.posY, p.posZ, ModSounds.JUMPSCARE, SoundCategory.HOSTILE, 2.0F, 1.0F);   // TPS S
        NetworkHandler.CHANNEL.sendTo(new PacketFx(PacketFx.JUMPSCARE, variant), p);
        p.addPotionEffect(new PotionEffect(MobEffects.BLINDNESS, 30, 0, false, false));                     // short darkness
        r.fogPrelude = Math.max(r.fogPrelude, 0.9F);

        Scheduler.schedule(55, new Runnable() {                                                             // aftermath
            @Override public void run() {
                if (!p.isDead) p.worldObj.playSound(null, p.posX, p.posY, p.posZ, ModSounds.WHISPER, SoundCategory.HOSTILE, 1.0F, 0.8F);
            }
        });
    }
}
