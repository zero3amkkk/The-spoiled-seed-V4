# THE SPOILED SEED — 0.1.1 v4

Minecraft Java 1.9.4 · Forge 1.9.4-12.17.0.2051 · ForgeGradle 2.2 · Java 8 · mappings snapshot_20160518

> ⚠️ **حالة البناء:** هذا الكود **لم يُبْنَ فعلياً** في بيئة الكتابة (لا يوجد إنترنت ولا Forge). تم فحص صياغة الكود بمترجم Java
> (لا أخطاء صياغة) وتمت مراجعة أسماء الـ API يدوياً، لكن **التحقق الحقيقي هو أول `gradle build`**. إن ظهر خطأ ابعته وسيُصلح.

## البناء من GitHub (بدون تثبيت شيء)
1. أنشئ مستودعاً على GitHub وارفع **محتويات** هذا المجلد (بما فيه `.github/workflows/build.yml`).
2. تبويب **Actions** → سيبدأ `Build mod` تلقائياً عند كل push (أو Run workflow).
3. بعد النجاح ✅: افتح التشغيلة → **Artifacts** → `TheSpoiledSeed-jar` → ستجد `TheSpoiledSeed-0.1.1-v4.jar`
   (ليس `-sources` ولا `-dev`) → ضعه في `.minecraft/mods` مع Forge 1.9.4.
4. إن فشل ❌: افتح الخطوة الحمراء، انسخ أسطر `error:` وأرسلها.

## ما أُصلح في v4 (توافق 1.9.4)
- `GuiSelectWorld` → `GuiWorldSelection` (شاشة العالم الفردي في 1.9.4).
- إزالة `setupFogColor(...)`؛ العيون المضيئة الآن تُرسم بدون ضباب (`disableFog/enableFog`) فتبقى مضيئة حتى وسط الضباب.
- مراجعة بقية الكود على نفس النمط.

## الجديد
**الوحش**: يتنبأ بمكان هروبك، يتوقف ويحدّق ثم ينطلق (feint/burst)، قلب ينبض عند اقترابه، يجري عليك إن حدّقت (50%).
**أنواع تهديد جديدة**: `window` (يقف خلف زجاج نافذتك ويطرق)، `mimic` (رسائل شات بإسمك أو بإسمه)،
`echo` (خطوات تقلد خطواتك وتتوقف حين تتوقف ثم نفَس خلفك)، `blackout` (انطفاء مشاعل كثيرة).
**الواجهة**: شاشة رئيسية بتصميمك مع صوت عند المرور/الضغط على كل خيار، موسيقى حزينة هادئة، عينان بيضاوان تفتحان أحياناً في الغابة، fade-in،
إصدار `0.1.1 v4`. قائمة socials (فتح/نسخ لكل رابط).
**Mod Options** (مفتاح O): Horror / Fog / Audio & UI / Progress / Controls / Tools. إعدادات الضباب (تشغيل + قوة 0-100 بشريط)، الجمب سكير،
السرقة، اللافتات، الرعب الليلي، مستوى الرعب، التقدم والتهديد، وإعدادات واجهة العميل (أصوات، موسيقى، تقليل الوميض، اهتزاز، HUD).
**مفاتيح تحكم مخصصة** (Options ▸ Controls ▸ The Spoiled Seed): فتح الإعدادات (O)، تبديل الضباب، تبديل الجمب سكير، الحالة، الكتاب.
**الأوامر `/ss`**: كل ما "يظهر" يمكن استدعاؤه: `spawn <observing|stalking|disturbance|jumpscare|chase|rush>`،
`play <sound>`، وكل الأحداث (`jumpscare chase stalk observe glimpse bed footsteps knock whisper sound cave sign torch door theft window mimic echo blackout`)،
`fog`, `stage`, `threat`, `locate`, `opt`, `give`, `guide`, `clear`, `status`, `reset`.

## ملاحظات
- أصوات اللعبة مولّدة برمجياً (OGG) والموسيقى مولّدة كذلك؛ يمكن استبدالها بأي OGG بنفس الأسماء.
- الأيقونة: `assets/spoiledseed/logo.png`.
