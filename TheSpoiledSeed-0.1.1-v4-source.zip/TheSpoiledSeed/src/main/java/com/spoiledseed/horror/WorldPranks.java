package com.spoiledseed.horror;

import com.spoiledseed.SpoiledSeed;
import com.spoiledseed.quest.QuestData;
import com.spoiledseed.registry.ModSounds;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import com.spoiledseed.entity.EntityNull;
import com.spoiledseed.entity.NullState;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.block.Block;
import net.minecraft.block.BlockDoor;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.init.SoundEvents;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityChest;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.WorldServer;

/** Ways The Null disturbs the world without being seen: sounds, torches, doors, chest theft. */
public class WorldPranks {
    private static final Random RAND = new Random();
    public static final String CHEST_KEY = "Chests";

    private static class Relight { WorldServer w; BlockPos pos; IBlockState state; int ticks; }
    private static final List<Relight> RELIGHTS = new ArrayList<Relight>();

    // ---- sounds ---------------------------------------------------------------------------
    public static void footsteps(final EntityPlayerMP p) {
        Vec3d look = p.getLookVec();
        double bx = -look.xCoord, bz = -look.zCoord, l = Math.sqrt(bx * bx + bz * bz);
        if (l < 0.01D) { bx = 0D; bz = -1D; l = 1D; }
        final double ux = bx / l, uz = bz / l;
        final WorldServer w = (WorldServer) p.worldObj;
        for (int i = 0; i < 7; i++) {
            final double dist = 9D - i * 1.1D;                 // walking up behind the player
            Scheduler.schedule(i * 11 + 1, new Runnable() {
                @Override public void run() {
                    if (p.isDead) return;
                    w.playSound(null, p.posX + ux * dist, p.posY, p.posZ + uz * dist, ModSounds.FOOTSTEP,
                            SoundCategory.HOSTILE, 1.0F, 0.85F + RAND.nextFloat() * 0.3F);
                }
            });
        }
    }

    /** Something RUNS through the cave toward you, then stops dead. Triggered while mining ore underground. */
    public static void caveRun(final EntityPlayerMP p) {
        double ang = RAND.nextDouble() * Math.PI * 2D;
        final double ux = Math.cos(ang), uz = Math.sin(ang);
        final WorldServer w = (WorldServer) p.worldObj;
        final int steps = 15;
        for (int i = 0; i < steps; i++) {
            final double dist = 26D - i * 1.6D;
            Scheduler.schedule(i * 3 + 1, new Runnable() {
                @Override public void run() {
                    if (p.isDead) return;
                    w.playSound(null, p.posX + ux * dist, p.posY, p.posZ + uz * dist, ModSounds.CHASE_STEP,
                            SoundCategory.HOSTILE, 1.1F, 1.25F + RAND.nextFloat() * 0.2F);
                }
            });
        }
        Scheduler.schedule(steps * 3 + 25, new Runnable() {          // it stops right next to you
            @Override public void run() {
                if (!p.isDead) w.playSound(null, p.posX + ux * 3D, p.posY, p.posZ + uz * 3D, ModSounds.BREATH, SoundCategory.HOSTILE, 1.3F, 0.7F);
            }
        });
    }

    public static void knock(EntityPlayerMP p) {
        double ang = RAND.nextDouble() * Math.PI * 2D;
        p.worldObj.playSound(null, p.posX + Math.cos(ang) * 2.5D, p.posY + 1D, p.posZ + Math.sin(ang) * 2.5D,
                ModSounds.KNOCK, SoundCategory.HOSTILE, 1.4F, 1F);
    }

    public static void whisper(EntityPlayerMP p) {
        Vec3d look = p.getLookVec();
        p.worldObj.playSound(null, p.posX - look.xCoord * 1.2D, p.posY + 1.4D, p.posZ - look.zCoord * 1.2D,
                ModSounds.WHISPER, SoundCategory.HOSTILE, 1.3F, 0.85F + RAND.nextFloat() * 0.2F);
    }

    public static void distantSound(EntityPlayerMP p) {
        SoundEvent[] pool = new SoundEvent[] { ModSounds.DRONE, ModSounds.SCRAPE, ModSounds.BREATH };
        double ang = RAND.nextDouble() * Math.PI * 2D, d = 8D + RAND.nextDouble() * 8D;
        p.worldObj.playSound(null, p.posX + Math.cos(ang) * d, p.posY, p.posZ + Math.sin(ang) * d,
                pool[RAND.nextInt(pool.length)], SoundCategory.AMBIENT, 1.3F, 0.8F + RAND.nextFloat() * 0.3F);
    }

    // ---- torches --------------------------------------------------------------------------
    /** 'count' torches within 8 blocks go out (they come back after 30-70 s). */
    public static void extinguish(EntityPlayerMP p, int count) {
        WorldServer w = (WorldServer) p.worldObj;
        BlockPos c = new BlockPos(p);
        List<BlockPos> found = new ArrayList<BlockPos>();
        for (int x = -8; x <= 8; x++)
            for (int y = -4; y <= 4; y++)
                for (int z = -8; z <= 8; z++) {
                    BlockPos b = c.add(x, y, z);
                    if (w.getBlockState(b).getBlock() == Blocks.TORCH) found.add(b);
                }
        Collections.shuffle(found, RAND);
        for (int i = 0; i < Math.min(count, found.size()); i++) {
            BlockPos b = found.get(i);
            Relight rl = new Relight();
            rl.w = w; rl.pos = b; rl.state = w.getBlockState(b); rl.ticks = (30 + RAND.nextInt(40)) * 20;
            RELIGHTS.add(rl);
            w.setBlockState(b, Blocks.AIR.getDefaultState());
            w.playSound(null, b.getX() + 0.5D, b.getY() + 0.5D, b.getZ() + 0.5D, SoundEvents.BLOCK_FIRE_EXTINGUISH, SoundCategory.BLOCKS, 0.6F, 1F);
        }
    }

    public static void tick() {
        if (RELIGHTS.isEmpty()) return;
        for (Iterator<Relight> it = RELIGHTS.iterator(); it.hasNext();) {
            Relight rl = it.next();
            if (--rl.ticks <= 0) { relight(rl); it.remove(); }
        }
    }

    private static void relight(Relight rl) {
        if (!rl.w.isAirBlock(rl.pos)) return;
        if (rl.state.getBlock().canPlaceBlockAt(rl.w, rl.pos)) rl.w.setBlockState(rl.pos, rl.state);
        else Block.spawnAsEntity(rl.w, rl.pos, new ItemStack(Blocks.TORCH));
    }

    public static void relightAll() {
        for (Relight rl : RELIGHTS) relight(rl);
        RELIGHTS.clear();
    }

    // ---- doors ----------------------------------------------------------------------------
    public static void toggleDoor(EntityPlayerMP p) {
        WorldServer w = (WorldServer) p.worldObj;
        BlockPos c = new BlockPos(p);
        List<BlockPos> doors = new ArrayList<BlockPos>();
        for (int x = -7; x <= 7; x++)
            for (int y = -2; y <= 2; y++)
                for (int z = -7; z <= 7; z++) {
                    BlockPos b = c.add(x, y, z);
                    IBlockState s = w.getBlockState(b);
                    if (s.getBlock() instanceof BlockDoor && s.getMaterial() == Material.WOOD
                            && s.getValue(BlockDoor.HALF) == BlockDoor.EnumDoorHalf.LOWER) doors.add(b);
                }
        if (doors.isEmpty()) return;
        BlockPos b = doors.get(RAND.nextInt(doors.size()));
        boolean open = BlockDoor.isOpen(w, b);
        ((BlockDoor) w.getBlockState(b).getBlock()).toggleDoor(w, b, !open);
    }

    // ---- theft: ONLY from chests the player placed, ordinary items only, always recoverable -------------
    private static boolean stealable(ItemStack s) {
        if (s == null || s.isItemStackDamageable() || s.isItemEnchanted() || s.hasDisplayName()) return false;
        Item it = s.getItem();
        if (it.getRegistryName() != null && it.getRegistryName().getResourceDomain().equals(SpoiledSeed.MODID)) return false;   // never quest items
        return it != Items.DIAMOND && it != Items.EMERALD && it != Items.NETHER_STAR && it != Items.WRITTEN_BOOK;
    }

    private static boolean isChest(WorldServer w, BlockPos pos) {
        Block b = w.getBlockState(pos).getBlock();
        return b == Blocks.CHEST || b == Blocks.TRAPPED_CHEST;
    }

    /** Player-placed chests within 'radius' blocks that still exist (stale entries are removed). */
    public static List<BlockPos> chestsNear(EntityPlayerMP p, int radius) {
        WorldServer w = (WorldServer) p.worldObj;
        List<BlockPos> out = new ArrayList<BlockPos>();
        for (BlockPos pos : QuestData.getPositions(p, CHEST_KEY)) {
            if (!w.isBlockLoaded(pos)) continue;
            if (!isChest(w, pos)) { QuestData.removePos(p, CHEST_KEY, pos); continue; }
            if (pos.distanceSq(p.posX, p.posY, p.posZ) <= radius * radius) out.add(pos);
        }
        return out;
    }

    /** Takes 1-3 items from one tracked chest and hides them in a new chest nearby. Returns false if nothing was possible. */
    public static boolean stealFromChest(EntityPlayerMP p) {
        WorldServer w = (WorldServer) p.worldObj;
        List<BlockPos> chests = chestsNear(p, 48);
        Collections.shuffle(chests, RAND);
        for (BlockPos cp : chests) {
            TileEntity te = w.getTileEntity(cp);
            if (!(te instanceof IInventory)) continue;
            IInventory inv = (IInventory) te;
            List<Integer> slots = new ArrayList<Integer>();
            for (int i = 0; i < inv.getSizeInventory(); i++) if (stealable(inv.getStackInSlot(i))) slots.add(Integer.valueOf(i));
            if (slots.isEmpty()) continue;
            BlockPos spot = SpawnHelper.findSpot(w, cp, p, 14, 28, false);
            if (spot == null) return false;                                   // no hiding place -> nothing is taken
            int slot = slots.get(RAND.nextInt(slots.size())).intValue();
            ItemStack have = inv.getStackInSlot(slot);
            ItemStack taken = inv.decrStackSize(slot, Math.min(have.stackSize, 1 + RAND.nextInt(3)));
            if (taken == null) continue;
            te.markDirty();

            w.setBlockState(spot, Blocks.CHEST.getDefaultState());           // the hiding place
            TileEntity hide = w.getTileEntity(spot);
            if (hide instanceof TileEntityChest) ((TileEntityChest) hide).setInventorySlotContents(13, taken);
            else Block.spawnAsEntity(w, spot, taken);

            w.playSound(null, cp.getX() + 0.5D, cp.getY() + 0.5D, cp.getZ() + 0.5D, SoundEvents.BLOCK_CHEST_CLOSE, SoundCategory.BLOCKS, 0.8F, 0.6F);
            double dx = spot.getX() - p.posX, dz = spot.getZ() - p.posZ;
            String dir = Math.abs(dx) > Math.abs(dz) ? (dx > 0 ? "east" : "west") : (dz > 0 ? "south" : "north");
            HorrorDirector.msg(p, "Your chest was opened while you weren't looking. What was taken lies to the " + dir + ", hidden above ground.");
            return true;
        }
        return false;
    }
    // ====================================================================================
    // v4: craftier threats
    // ====================================================================================

    /** WINDOW: it stands right outside one of your windows and stares in, tapping the glass. */
    public static boolean window(EntityPlayerMP p, PlayerHorror r) {
        WorldServer w = (WorldServer) p.worldObj;
        if (HorrorDirector.findNull(w, r) != null || QuestData.isSealed(p)) return false;
        BlockPos c = new BlockPos(p);
        List<BlockPos> glass = new ArrayList<BlockPos>();
        for (int x = -6; x <= 6; x++)
            for (int y = -1; y <= 3; y++)
                for (int z = -6; z <= 6; z++) {
                    BlockPos b = c.add(x, y, z);
                    if (w.getBlockState(b).getMaterial() == Material.GLASS) glass.add(b);
                }
        Collections.shuffle(glass, RAND);
        for (BlockPos g : glass) {
            int dx = g.getX() - c.getX(), dz = g.getZ() - c.getZ();
            EnumFacing out = Math.abs(dx) >= Math.abs(dz) ? (dx >= 0 ? EnumFacing.EAST : EnumFacing.WEST) : (dz >= 0 ? EnumFacing.SOUTH : EnumFacing.NORTH);
            for (int dist = 1; dist <= 3; dist++) {
                BlockPos spot = g.offset(out, dist);
                for (int dy = 0; dy >= -2; dy--) {                    // glass may be a window above ground level
                    BlockPos s = spot.add(0, dy, 0);
                    if (w.isAirBlock(s) && w.isAirBlock(s.up()) && w.getBlockState(s.down()).getMaterial().isSolid()) {
                        w.playSound(null, g.getX() + 0.5D, g.getY() + 0.5D, g.getZ() + 0.5D, ModSounds.TAP, SoundCategory.HOSTILE, 1.4F, 1F);
                        EntityNull n = SpawnHelper.spawnAt(p, r, s, NullState.OBSERVING, 110, false, 0F);
                        if (n != null) n.setPeekMode(2.2F);
                        return n != null;
                    }
                }
            }
        }
        return false;
    }

    private static final String[] MIMIC_LINES = {
        "don't turn around", "i'm right behind you", "why did you break it", "it knows where you sleep",
        "look at the tree line", "can you hear it too", "behind the glass", "stop digging", "it is so cold here",
        "i can see your house", "do not look at the eyes", "it's inside the fog"
    };

    /** MIMIC: chat messages that look like they come from you - or from IT. */
    public static void mimic(final EntityPlayerMP p) {
        boolean itself = RAND.nextInt(3) == 0;
        String name = itself ? "Null" : p.getName();
        send(p, name, MIMIC_LINES[RAND.nextInt(MIMIC_LINES.length)]);
        final String n2 = name;
        if (RAND.nextBoolean()) {
            Scheduler.schedule(40 + RAND.nextInt(60), new Runnable() {
                @Override public void run() { if (!p.isDead) send(p, n2, MIMIC_LINES[RAND.nextInt(MIMIC_LINES.length)]); }
            });
        }
        p.worldObj.playSound(null, p.posX, p.posY, p.posZ, ModSounds.WHISPER, SoundCategory.HOSTILE, 0.8F, 1.1F);
    }

    private static void send(EntityPlayerMP p, String name, String line) {
        p.addChatMessage(new TextComponentString("<" + name + "> " + line));
    }

    /** ECHO: footsteps that copy YOUR steps behind you - and stop when you stop. Then a breath, very close. */
    public static void echo(final EntityPlayerMP p) {
        final double[] last = { p.posX, p.posZ };
        final int[] still = { 0 };
        final int[] steps = { 0 };
        final int[] ticks = { 0 };
        final WorldServer w = (WorldServer) p.worldObj;
        Runnable step = new Runnable() {
            @Override public void run() {
                if (p.isDead || ++ticks[0] > 60) return;
                double dx = p.posX - last[0], dz = p.posZ - last[1];
                if (Math.sqrt(dx * dx + dz * dz) >= 1.1D) {
                    last[0] = p.posX; last[1] = p.posZ;
                    still[0] = 0;
                    steps[0]++;
                    Vec3d look = p.getLookVec();
                    double bx = -look.xCoord, bz = -look.zCoord, l = Math.sqrt(bx * bx + bz * bz);
                    if (l < 0.01D) { bx = 0D; bz = -1D; l = 1D; }
                    double dist = 3.5D + RAND.nextDouble() * 1.5D;
                    w.playSound(null, p.posX + bx / l * dist, p.posY, p.posZ + bz / l * dist, ModSounds.FOOTSTEP, SoundCategory.HOSTILE, 0.9F, 0.9F + RAND.nextFloat() * 0.2F);
                } else if (++still[0] >= 10 && steps[0] >= 4) {          // you stopped; it did too... right behind you
                    Vec3d look = p.getLookVec();
                    w.playSound(null, p.posX - look.xCoord * 1.5D, p.posY + 1D, p.posZ - look.zCoord * 1.5D, ModSounds.BREATH, SoundCategory.HOSTILE, 1.3F, 0.7F);
                    return;
                }
                Scheduler.schedule(5, this);
            }
        };
        Scheduler.schedule(8, step);
    }

    /** BLACKOUT: many torches around you go out at once. */
    public static void blackout(EntityPlayerMP p) {
        extinguish(p, 10);
        p.worldObj.playSound(null, p.posX, p.posY, p.posZ, ModSounds.STING, SoundCategory.HOSTILE, 0.7F, 0.6F);
        p.worldObj.playSound(null, p.posX, p.posY, p.posZ, ModSounds.HEARTBEAT, SoundCategory.HOSTILE, 1.2F, 0.9F);
    }

    /** Plays one of the mod's sounds at the player (used by /ss play). */
    public static boolean playNamed(EntityPlayerMP p, String name) {
        SoundEvent e = ModSounds.byName(name);
        if (e == null) return false;
        p.worldObj.playSound(null, p.posX, p.posY, p.posZ, e, SoundCategory.HOSTILE, 1.5F, 1F);
        return true;
    }
}
