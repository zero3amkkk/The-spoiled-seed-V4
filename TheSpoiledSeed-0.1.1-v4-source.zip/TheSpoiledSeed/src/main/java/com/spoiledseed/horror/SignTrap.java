package com.spoiledseed.horror;

import com.spoiledseed.config.ModConfig;
import com.spoiledseed.quest.QuestData;
import java.util.List;
import java.util.Random;
import net.minecraft.block.BlockStandingSign;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.Blocks;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntitySign;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.WorldServer;

/** Cursed signs: threatening text in the player's surroundings. Breaking one has an 85% chance to trigger a jumpscare. */
public class SignTrap {
    public static final String KEY = "Signs";
    public static final float TRIGGER_CHANCE = 0.85F;
    private static final Random RAND = new Random();

    private static final String[][] TEXTS = {
        { "TURN BACK", "NOW", "", "I SEE YOU" },
        { "IT IS", "BEHIND YOU", "", "" },
        { "DO NOT", "LOOK AT IT", "", "" },
        { "YOU ARE NOT", "ALONE HERE", "", "" },
        { "LEAVE", "WHILE YOU", "CAN", "" },
        { "HE WATCHES", "FROM THE", "TREES", "" },
        { "STOP", "DIGGING", "", "" },
        { "RUN", "", "", "" },
        { "I FOUND", "YOUR HOUSE", "", "" },
        { "DO NOT", "BREAK ME", "", "" }
    };

    public static void place(EntityPlayerMP p) {
        WorldServer w = (WorldServer) p.worldObj;
        BlockPos g = SpawnHelper.findSpot(w, new BlockPos(p), p, 10, 24, false);
        if (g == null) return;
        IBlockState st = Blocks.STANDING_SIGN.getDefaultState().withProperty(BlockStandingSign.ROTATION, Integer.valueOf(RAND.nextInt(16)));
        w.setBlockState(g, st, 3);
        TileEntity te = w.getTileEntity(g);
        if (!(te instanceof TileEntitySign)) { w.setBlockToAir(g); return; }
        String[] lines = TEXTS[RAND.nextInt(TEXTS.length)];
        TileEntitySign sign = (TileEntitySign) te;
        for (int i = 0; i < 4; i++) sign.signText[i] = new TextComponentString(lines[i]);
        sign.markDirty();
        w.notifyBlockUpdate(g, st, st, 3);
        QuestData.addPos(p, KEY, g, ModConfig.maxSigns);
    }

    public static boolean isCursed(EntityPlayerMP p, BlockPos pos) {
        return QuestData.hasPos(p, KEY, pos);
    }

    /** Called when the player breaks a cursed sign. */
    public static void onBroken(EntityPlayerMP p, BlockPos pos) {
        QuestData.removePos(p, KEY, pos);
        if (RAND.nextFloat() < TRIGGER_CHANCE && QuestData.optJump(p)) {
            Jumpscare.trigger(p, HorrorDirector.rec(p), true);
        }
    }

    public static boolean hasAny(EntityPlayerMP p) {
        List<BlockPos> l = QuestData.getPositions(p, KEY);
        return l.size() >= ModConfig.maxSigns;
    }
}
