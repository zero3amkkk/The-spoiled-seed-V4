package com.spoiledseed.quest;

import com.spoiledseed.horror.HorrorDirector;
import com.spoiledseed.horror.PlayerHorror;
import com.spoiledseed.registry.ModItems;
import com.spoiledseed.registry.ModSounds;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextFormatting;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.PlayerEvent;

/**
 * The 5 main quests. QuestData.stage = number of completed quests.
 * Q1 First Sighting (survive a chase) | Q2 Black Fog (3 samples) | Q3 Forgotten Place (ancient journal)
 * Q4 Three Relics (echo + core + seal) | Q5 Final Ritual (see FinalRitual)
 * THREAT: every NEW ritual item the player finds raises the threat level (see trackThreat).
 */
public class QuestManager {
    public static int count(EntityPlayerMP p, Item item) {
        int n = 0;
        for (ItemStack s : p.inventory.mainInventory) if (s != null && s.getItem() == item) n += s.stackSize;
        return n;
    }

    private static void advance(EntityPlayerMP p, int stage, String text) {
        QuestData.setStage(p, stage);
        p.addChatMessage(new TextComponentString(TextFormatting.GOLD + "[Quest] " + TextFormatting.GRAY + text));
    }

    public static void tick(EntityPlayerMP p) {
        trackThreat(p);
        switch (QuestData.getStage(p)) {
            case 1:
                if (count(p, ModItems.corruptedSample) >= 3)
                    advance(p, 2, "THE BLACK FOG complete. Three scars, three samples. Something older lies beneath the dead ground - a Forgotten Ruin.");
                break;
            case 2:
                if (count(p, ModItems.journalAncient) >= 1)
                    advance(p, 3, "THE FORGOTTEN PLACE complete. Read the Ancient Journal. Gather the Echo Fragment, the Corrupted Core and the Forgotten Seal.");
                break;
            case 3:
                if (count(p, ModItems.relicEcho) >= 1 && count(p, ModItems.relicCore) >= 1 && count(p, ModItems.relicSeal) >= 1)
                    advance(p, 4, "THE THREE RELICS complete. Combine them into THE NULL SEAL, then take an Ancient Altar somewhere open.");
                break;
            default:
                break;
        }
    }

    // ---- threat ---------------------------------------------------------------------------
    private static final String[] KEYS = { "sample", "echo", "core", "seal", "journal" };

    private static Item[] items() {
        return new Item[] { ModItems.corruptedSample, ModItems.relicEcho, ModItems.relicCore, ModItems.relicSeal, ModItems.journalAncient };
    }

    /** Each time the player holds MORE of a ritual item than ever before, the threat goes up by one. */
    private static void trackThreat(EntityPlayerMP p) {
        Item[] it = items();
        int gained = 0;
        for (int i = 0; i < it.length; i++) {
            int now = count(p, it[i]);
            int seen = QuestData.getSeen(p, KEYS[i]);
            if (now > seen) { gained += now - seen; QuestData.setSeen(p, KEYS[i], now); }
        }
        if (gained <= 0) return;
        int before = QuestData.getThreat(p);
        QuestData.setThreat(p, before + gained);
        if (QuestData.getThreat(p) == before) return;                 // already at maximum
        p.addChatMessage(new TextComponentString(TextFormatting.DARK_RED + "" + TextFormatting.ITALIC
                + "Something turns its head toward you. It knows what you hold. (Threat " + QuestData.getThreat(p) + "/" + QuestData.MAX_THREAT + ")"));
        p.worldObj.playSound(null, p.posX, p.posY, p.posZ, ModSounds.HEARTBEAT, SoundCategory.HOSTILE, 1.2F, 0.9F);
        PlayerHorror r = HorrorDirector.rec(p);
        r.fogPrelude = Math.max(r.fogPrelude, 0.7F);
        r.cooldown = Math.min(r.cooldown, 25);                        // it comes sooner
    }

    /** Marks the current inventory as already seen (used by /ss give so it does not count as finds). */
    public static void syncSeen(EntityPlayerMP p) {
        Item[] it = items();
        for (int i = 0; i < it.length; i++) QuestData.setSeen(p, KEYS[i], Math.max(QuestData.getSeen(p, KEYS[i]), count(p, it[i])));
    }

    /** Quest 1: called when a chase ended with the player alive. */
    public static void onChaseSurvived(EntityPlayer p) {
        if (!(p instanceof EntityPlayerMP) || QuestData.getStage(p) != 0) return;
        EntityPlayerMP mp = (EntityPlayerMP) p;
        advance(mp, 1, "THE FIRST SIGHTING complete. You survived. A torn journal lies in your pack - right-click it.");
        ItemStack j = new ItemStack(ModItems.journalTorn);
        if (!mp.inventory.addItemStackToInventory(j)) mp.entityDropItem(j, 0F);
    }

    @SubscribeEvent
    public void onCrafted(PlayerEvent.ItemCraftedEvent e) {
        if (e.crafting != null && e.crafting.getItem() == ModItems.nullSeal && !e.player.worldObj.isRemote) {
            e.player.addChatMessage(new TextComponentString(TextFormatting.GOLD + "[Quest] " + TextFormatting.GRAY
                    + "The Null Seal is whole. Take an Ancient Altar somewhere open and right-click it with the Seal."));
        }
    }
}
