package com.spoiledseed.horror;

import com.spoiledseed.config.ModConfig;
import com.spoiledseed.entity.EntityNull;
import com.spoiledseed.entity.NullState;
import com.spoiledseed.network.NetworkHandler;
import com.spoiledseed.network.PacketFx;
import com.spoiledseed.quest.FinalRitual;
import com.spoiledseed.quest.QuestData;
import com.spoiledseed.quest.QuestManager;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.UUID;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.world.WorldServer;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.PlayerEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.fml.relauncher.Side;

/**
 * Decides WHEN things happen to each player (once per second).
 * What raises the pressure: play time, quest stage, THREAT (every ritual item found), NIGHT, and being near HOME
 * (your bed, or the world spawn). The player's Mod Options (fog, jumpscares, theft, signs, level) are respected.
 */
public class HorrorDirector {
    public static final Random RAND = new Random();
    private static final Map<UUID, PlayerHorror> PLAYERS = new HashMap<UUID, PlayerHorror>();
    private static final float[] LEVEL_MULT = { 0.5F, 1.0F, 1.6F };

    public static PlayerHorror rec(EntityPlayer p) {
        PlayerHorror r = PLAYERS.get(p.getUniqueID());
        if (r == null) { r = new PlayerHorror(); PLAYERS.put(p.getUniqueID(), r); }
        return r;
    }

    public static void reset() {
        PLAYERS.clear();
        Scheduler.clear();
        FinalRitual.clearAll();
    }

    public static void msg(EntityPlayer p, String s) {
        p.addChatMessage(new TextComponentString(TextFormatting.DARK_GRAY + "" + TextFormatting.ITALIC + s));
    }

    public static void sendOptions(EntityPlayerMP p) {
        NetworkHandler.CHANNEL.sendTo(new PacketFx(PacketFx.OPTIONS, QuestData.optMask(p)), p);
    }

    public static void sendStats(EntityPlayerMP p) {
        NetworkHandler.CHANNEL.sendTo(new PacketFx(PacketFx.STATS, QuestData.getStage(p) + 16 * QuestData.getThreat(p),
                QuestData.getSeconds(p) / 60F), p);
    }

    // ---- world context --------------------------------------------------------------------
    public static boolean isNight(WorldServer w) {
        long t = w.getWorldTime() % 24000L;
        return t >= 13000L && t <= 23000L;
    }

    public static boolean isNearHome(EntityPlayerMP p) {
        WorldServer w = (WorldServer) p.worldObj;
        BlockPos home = p.getBedLocation();
        if (home == null) home = w.getSpawnPoint();
        double dx = p.posX - home.getX(), dz = p.posZ - home.getZ();
        return dx * dx + dz * dz <= (double) ModConfig.homeRadius * ModConfig.homeRadius;
    }

    public static boolean isUnderground(EntityPlayerMP p) {
        return p.posY < 55D && !p.worldObj.canSeeSky(new BlockPos(p));
    }

    // ---- Forge events ---------------------------------------------------------------------
    @SubscribeEvent
    public void onPlayerTick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || e.side != Side.SERVER || !(e.player instanceof EntityPlayerMP)) return;
        if (e.player.ticksExisted % 20 != 0) return;
        try {
            secondTick((EntityPlayerMP) e.player);
        } catch (RuntimeException ex) {
            ex.printStackTrace();           // a horror bug must never crash the server
        }
    }

    @SubscribeEvent
    public void onServerTick(TickEvent.ServerTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Scheduler.tick();
        WorldPranks.tick();
    }

    @SubscribeEvent
    public void onLogout(PlayerEvent.PlayerLoggedOutEvent e) {
        if (e.player instanceof EntityPlayerMP) FinalRitual.cancel((EntityPlayerMP) e.player, null);
        PLAYERS.remove(e.player.getUniqueID());
    }

    @SubscribeEvent
    public void onDeath(LivingDeathEvent e) {
        if (!(e.getEntityLiving() instanceof EntityPlayerMP)) return;
        EntityPlayerMP p = (EntityPlayerMP) e.getEntityLiving();
        FinalRitual.cancel(p, "The altar goes dark.");
        PlayerHorror r = PLAYERS.get(p.getUniqueID());
        if (r != null) { r.pending = null; r.cooldown = Math.max(r.cooldown, 60); }
    }

    // ---- main loop ------------------------------------------------------------------------
    private void secondTick(EntityPlayerMP p) {
        QuestData.addSeconds(p, 1);
        PlayerHorror r = rec(p);
        if (p.dimension != 0 || p.isDead) { FogController.send(p, r, 0F); return; }

        QuestManager.tick(p);
        if (p.ticksExisted % 200 == 0) sendStats(p);
        if (r.jumpCd > 0) r.jumpCd--;
        if (r.caveCd > 0) r.caveCd--;
        if (QuestData.isSealed(p)) { FogController.send(p, r, 0F); return; }

        WorldServer w = (WorldServer) p.worldObj;
        EntityNull n = findNull(w, r);
        float intensity = intensity(p);
        boolean night = isNight(w);
        boolean home = isNearHome(p);
        int threat = QuestData.getThreat(p);

        FogController.second(p, r, n, intensity, night);   // fog from the first second, independent of the monster
        if (n == null && r.nullId != null) {               // it vanished -> cooldown before it can return
            r.nullId = null;
            r.cooldown = Math.max(r.cooldown, nextCooldown(intensity, night, home, threat));
        }

        if (!ModConfig.affectCreative && (p.capabilities.isCreativeMode || p.isSpectator())) return;
        if (FinalRitual.isActive(p)) { FinalRitual.tick(p, n); return; }
        if (n != null) return;
        if (QuestData.getSeconds(p) < ModConfig.graceSeconds) return;

        // scary sounds drift in on their own at night
        if (night && QuestData.optAmbient(p) && RAND.nextFloat() < 0.004F * (1F + intensity * 2F + threat * 0.1F)) {
            if (RAND.nextBoolean()) WorldPranks.distantSound(p); else WorldPranks.whisper(p);
        }

        if (r.pending != null) {                           // event waiting behind a fog prelude
            if (--r.pendingDelay <= 0) { HorrorEvent e = r.pending; r.pending = null; run(p, e, false); }
            return;
        }
        if (r.cooldown > 0) { r.cooldown--; return; }

        float timeFactor = Math.min(1F, QuestData.getSeconds(p) / 7200F);
        float prob = ModConfig.eventProbability * LEVEL_MULT[QuestData.optLevel(p)]
                * (1F + timeFactor * 0.8F)                 // the longer you play, the more it comes
                * (night ? 1.6F : 1F)
                * (home ? 1.3F : 1F)
                * (1F + threat * 0.08F);
        if (RAND.nextFloat() > Math.min(0.97F, prob)) { r.cooldown = 20 + RAND.nextInt(25); return; }

        HorrorEvent ev = pick(p, intensity, night, home);
        if (ModConfig.fogEnabled && QuestData.optFog(p) && ev.spawnsNull() && RAND.nextFloat() < ModConfig.fogBeforeEncounterChance) {
            r.pending = ev;                                // fog thickens first, monster 8 s later
            r.pendingDelay = 8;
            r.fogPrelude = 1F;
        } else {
            run(p, ev, false);
        }
        r.cooldown = nextCooldown(intensity, night, home, threat);
    }

    /** 0..1, grows with play time, quest stage and threat. */
    public static float intensity(EntityPlayer p) {
        float t = Math.min(1F, QuestData.getSeconds(p) / 7200F);
        return Math.min(1F, 0.1F + QuestData.getStage(p) * 0.18F + t * 0.4F + QuestData.getThreat(p) * 0.05F);
    }

    private static int nextCooldown(float intensity, boolean night, boolean home, int threat) {
        double base = ModConfig.eventIntervalSeconds * (0.6D + RAND.nextDouble() * 0.8D);
        base /= (1.0D + 2.0D * intensity);
        if (night) base /= 1.5D;
        if (home) base /= 1.4D;
        base /= (1.0D + threat * 0.05D);
        return Math.max(12, (int) base + 12);
    }

    private static void add(Map<HorrorEvent, Float> w, HorrorEvent e, float weight) { w.put(e, Float.valueOf(weight)); }
    private static void mul(Map<HorrorEvent, Float> w, HorrorEvent e, float f) {
        Float v = w.get(e);
        if (v != null) w.put(e, Float.valueOf(v.floatValue() * f));
    }

    private static HorrorEvent pick(EntityPlayerMP p, float intensity, boolean night, boolean home) {
        int stage = QuestData.getStage(p);
        if (stage == 0 && QuestData.getSeconds(p) > ModConfig.graceSeconds + 900) return HorrorEvent.CHASE;   // guarantees the first encounter

        Map<HorrorEvent, Float> w = new EnumMap<HorrorEvent, Float>(HorrorEvent.class);
        add(w, HorrorEvent.OBSERVE, 5);
        add(w, HorrorEvent.GLIMPSE, 3);
        add(w, HorrorEvent.FOOTSTEPS, 3);
        add(w, HorrorEvent.SOUND, 3);
        add(w, HorrorEvent.KNOCK, 2);
        add(w, HorrorEvent.WHISPER, 2);
        add(w, HorrorEvent.TORCH, 2);
        add(w, HorrorEvent.DOOR, 2);
        add(w, HorrorEvent.ECHO, 3);
        add(w, HorrorEvent.WINDOW, 3);
        if (QuestData.optSigns(p) && !SignTrap.hasAny(p)) add(w, HorrorEvent.SIGN, 2);
        if (isUnderground(p)) add(w, HorrorEvent.CAVE, 6);
        if (stage >= 1) {
            add(w, HorrorEvent.STALK, 3 + stage);
            add(w, HorrorEvent.BED, 2);
            add(w, HorrorEvent.CHASE, 2 + stage);
            add(w, HorrorEvent.MIMIC, 2);
            add(w, HorrorEvent.BLACKOUT, 1);
            if (ModConfig.jumpscareEnabled && QuestData.optJump(p)) add(w, HorrorEvent.JUMPSCARE, 2 + stage / 2);
        } else if (intensity > 0.3F) {
            add(w, HorrorEvent.STALK, 2);
        }
        if (ModConfig.theftEnabled && QuestData.optTheft(p) && !WorldPranks.chestsNear(p, 48).isEmpty()) add(w, HorrorEvent.THEFT, 2);

        if (night) {                                       // sounds, scares and sightings are more common at night
            mul(w, HorrorEvent.FOOTSTEPS, 2F); mul(w, HorrorEvent.SOUND, 2F); mul(w, HorrorEvent.WHISPER, 2F);
            mul(w, HorrorEvent.KNOCK, 2F); mul(w, HorrorEvent.JUMPSCARE, 2F); mul(w, HorrorEvent.OBSERVE, 1.5F);
            mul(w, HorrorEvent.STALK, 1.5F); mul(w, HorrorEvent.SIGN, 1.5F);
            mul(w, HorrorEvent.WINDOW, 2F); mul(w, HorrorEvent.ECHO, 1.5F); mul(w, HorrorEvent.MIMIC, 1.5F);
        }
        if (home) {                                        // it haunts your bed and your base
            mul(w, HorrorEvent.BED, 3F); mul(w, HorrorEvent.THEFT, 3F); mul(w, HorrorEvent.TORCH, 3F);
            mul(w, HorrorEvent.DOOR, 2.5F); mul(w, HorrorEvent.KNOCK, 2.5F); mul(w, HorrorEvent.FOOTSTEPS, 1.5F);
            mul(w, HorrorEvent.OBSERVE, 1.3F); mul(w, HorrorEvent.WINDOW, 2F); mul(w, HorrorEvent.BLACKOUT, 2.5F);
            if (!w.containsKey(HorrorEvent.BED)) add(w, HorrorEvent.BED, 3);
        }

        float total = 0F;
        for (Float v : w.values()) total += v.floatValue();
        float roll = RAND.nextFloat() * Math.max(0.001F, total);
        for (Map.Entry<HorrorEvent, Float> en : w.entrySet()) {
            roll -= en.getValue().floatValue();
            if (roll < 0F) return en.getKey();
        }
        return HorrorEvent.OBSERVE;
    }


    // ---- executing events (also used by /ss) -----------------------------------------------
    /** force = ignore cooldowns and replace any monster already present (used by commands). */
    public static void run(EntityPlayerMP p, HorrorEvent e, boolean force) {
        PlayerHorror r = rec(p);
        float in = intensity(p);
        if (force && (e.spawnsNull() || e == HorrorEvent.JUMPSCARE)) {
            clearNull(p);
            r.pending = null;
        }
        boolean home = isNearHome(p);
        switch (e) {
            case OBSERVE:
                SpawnHelper.spawn(p, r, NullState.OBSERVING, 22, 36, 20 * (25 + RAND.nextInt(30)), false, 0F, true);
                break;
            case GLIMPSE:
                SpawnHelper.spawn(p, r, NullState.OBSERVING, 12, 22, 80, false, 0F, true);
                break;
            case STALK:
                SpawnHelper.spawn(p, r, NullState.STALKING, 24, 34, 20 * 40, false, 0.2F + 0.4F * in, true);
                break;
            case CHASE:
                SpawnHelper.spawn(p, r, NullState.CHASE, 16, 26, 0, false, 0F, false);
                break;
            case BED:
                spawnNearBed(p, r);
                break;
            case JUMPSCARE:
                Jumpscare.trigger(p, r, force);
                break;
            case FOOTSTEPS:
                WorldPranks.footsteps(p);
                break;
            case KNOCK:
                WorldPranks.knock(p);
                break;
            case WHISPER:
                WorldPranks.whisper(p);
                break;
            case SOUND:
                WorldPranks.distantSound(p);
                break;
            case CAVE:
                WorldPranks.caveRun(p);
                break;
            case SIGN:
                SignTrap.place(p);
                break;
            case WINDOW:
                if (!WorldPranks.window(p, r)) {                                   // no window nearby -> it taps on the wall instead
                    WorldPranks.knock(p);
                    p.worldObj.playSound(null, p.posX, p.posY, p.posZ, com.spoiledseed.registry.ModSounds.TAP, net.minecraft.util.SoundCategory.HOSTILE, 1.0F, 0.9F);
                }
                break;
            case MIMIC:
                WorldPranks.mimic(p);
                break;
            case ECHO:
                WorldPranks.echo(p);
                break;
            case BLACKOUT:
                WorldPranks.blackout(p);
                lurk(p, r);
                break;
            case TORCH:
                WorldPranks.extinguish(p, home ? 5 : 3);
                lurk(p, r);
                break;
            case DOOR:
                WorldPranks.toggleDoor(p);
                lurk(p, r);
                break;
            case THEFT:
                if (!WorldPranks.stealFromChest(p)) WorldPranks.knock(p);      // nothing to take -> it only knocks
                lurk(p, r);
                break;
        }
    }

    /** DISTURBANCE: sometimes it stands in the distance while it interferes with the world. */
    private static void lurk(EntityPlayerMP p, PlayerHorror r) {
        if (RAND.nextFloat() < 0.5F) SpawnHelper.spawn(p, r, NullState.DISTURBANCE, 14, 22, 200, false, 0F, true);
    }

    private static void spawnNearBed(EntityPlayerMP p, PlayerHorror r) {
        WorldServer w = (WorldServer) p.worldObj;
        BlockPos bed = p.getBedLocation();
        BlockPos pos = null;
        if (bed != null && bed.distanceSq(p.posX, p.posY, p.posZ) < 64 * 64) pos = SpawnHelper.standingSpotAround(w, bed, 4, 7, null);
        if (pos == null || findNull(w, r) != null) {
            SpawnHelper.spawn(p, r, NullState.OBSERVING, 14, 22, 120, false, 0F, true);
            return;
        }
        SpawnHelper.spawnAt(p, r, pos, NullState.OBSERVING, 120, false, 0F);
    }

    // ---- monster bookkeeping ---------------------------------------------------------------
    public static EntityNull findNull(WorldServer w, PlayerHorror r) {
        if (r.nullId == null) return null;
        Entity e = w.getEntityFromUuid(r.nullId);
        return (e instanceof EntityNull && !e.isDead) ? (EntityNull) e : null;
    }

    /** Removes the player's monster instantly (no vanish effect). */
    public static void clearNull(EntityPlayerMP p) {
        PlayerHorror r = rec(p);
        EntityNull n = findNull((WorldServer) p.worldObj, r);
        if (n != null) n.setDead();
        r.nullId = null;
    }
}
