package com.spoiledseed.guide;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.nbt.NBTTagString;

/** The Survivor's Guide: a vanilla written book (so it opens like any book) with clickable command buttons. */
public class GuideBook {
    private static final String TAG = "SpoiledGuide";

    public static ItemStack create() {
        ItemStack s = new ItemStack(Items.WRITTEN_BOOK);
        NBTTagCompound tag = new NBTTagCompound();
        tag.setString("title", "Survivor's Guide");
        tag.setString("author", "???");
        tag.setBoolean(TAG, true);
        NBTTagList pages = new NBTTagList();
        for (String p : pages()) pages.appendTag(new NBTTagString(p));
        tag.setTag("pages", pages);
        s.setTagCompound(tag);
        return s;
    }

    public static boolean has(EntityPlayer p) {
        for (ItemStack s : p.inventory.mainInventory) {
            if (s != null && s.getItem() == Items.WRITTEN_BOOK && s.hasTagCompound() && s.getTagCompound().getBoolean(TAG)) return true;
        }
        return false;
    }

    // ---- page building -------------------------------------------------------------------
    private static String esc(String s) {
        return s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n");
    }

    private static String t(String text, String color) {
        return "{\"text\":\"" + esc(text) + "\",\"color\":\"" + color + "\"}";
    }

    private static String b(String label, String cmd, String color) {
        return "{\"text\":\"" + esc(label) + "\",\"color\":\"" + color + "\",\"clickEvent\":{\"action\":\"run_command\",\"value\":\"" + esc(cmd) + "\"}}";
    }

    private static String page(String... parts) {
        StringBuilder sb = new StringBuilder("[\"\"");
        for (String p : parts) sb.append(",").append(p);
        return sb.append("]").toString();
    }

    private static String[] pages() {
        return new String[] {
            page(t("THE SPOILED SEED\n", "dark_red"), t("Survivor's Guide\n\n", "black"),
                 t("Something is watching you. It was here before the fog.\n\nRead every page.\n\n", "black"),
                 t("Press O anywhere in the world for the Mod Options screen. Pages 7-10 have command buttons.", "dark_gray")),
            page(t("THE NULL\n\n", "dark_red"),
                 t("A black figure with white eyes. It watches, follows, moves your things, and sometimes... screams.\n\nIt cannot be killed. Hit it, stare at it or walk toward it and it leaves.", "black")),
            page(t("SURVIVING\n\n", "dark_red"),
                 t("Fog is always around; thicker = it may be near.\n\nIn a chase the hearts bar shows how far it is. Break line of sight; it gives up after ~25 s. If it catches you: a hit, a scream, or worse.\n\nStaring at it can make it CHARGE.", "black")),
            page(t("DANGERS\n\n", "dark_red"),
                 t("Night: it comes more, and screams more.\nNear your bed or spawn: it haunts you.\nIt only takes items from chests YOU placed - they are hidden, never gone.\nRunning steps in a cave: stop mining and think.\nThreatening signs: do not break them.\nEvery ritual item you find makes it hungrier.", "black")),
            page(t("QUEST 1\n", "dark_red"), t("The First Sighting\nSurvive a chase. You get the Torn Journal.\n\n", "black"),
                 t("QUEST 2\n", "dark_red"), t("The Black Fog\nBring 3 Corrupted Samples from Corrupted Sites: soul sand platforms with a chest.", "black")),
            page(t("QUEST 3\n", "dark_red"), t("The Forgotten Place\nA mossy platform with no chest hides a ladder down. Find the Ancient Journal.\n\n", "black"),
                 t("QUEST 4\n", "dark_red"), t("Three Relics\nEcho Fragment: obsidian Shrine.\nCorrupted Core: netherrack Cairn.\nForgotten Seal: the Ruin.", "black")),
            page(t("QUEST 5\n", "dark_red"), t("The Final Ritual\n1. Craft THE NULL SEAL (3 relics, any order).\n2. Place an Ancient Altar in the open.\n3. Right-click it holding the Seal.\n4. Charge it 3 times, ~8 s apart.\n5. Never go 48+ blocks away.\n\nThe Null will hunt you meanwhile.", "black")),
            page(t("TOOLS\n", "dark_red"),
                 b("[Status]\n", "/ss status", "dark_blue"),
                 b("[Locate Site]\n", "/ss locate site", "dark_blue"),
                 b("[Locate Shrine]\n", "/ss locate shrine", "dark_blue"),
                 b("[Locate Cairn]\n", "/ss locate cairn", "dark_blue"),
                 b("[Locate Ruin]\n", "/ss locate ruin", "dark_blue"),
                 b("[Quest items]\n", "/ss give", "dark_blue"),
                 b("[Help]", "/ss help", "dark_blue")),
            page(t("SCARES\n", "dark_red"),
                 b("[Jumpscare]\n", "/ss jumpscare", "red"),
                 b("[Chase]\n", "/ss chase", "red"),
                 b("[Stalk]\n", "/ss stalk", "red"),
                 b("[Observe]\n", "/ss observe", "red"),
                 b("[Glimpse]\n", "/ss glimpse", "red"),
                 b("[Bed]\n", "/ss bed", "red"),
                 b("[Remove Null]", "/ss clear", "red")),
            page(t("WORLD\n", "dark_red"),
                 b("[Fog 40]  ", "/ss fog 40", "dark_purple"), b("[Fog 100]\n", "/ss fog 100", "dark_purple"),
                 b("[Fog off]\n", "/ss fog off", "dark_purple"),
                 b("[Footsteps]\n", "/ss footsteps", "dark_purple"),
                 b("[Knock]  ", "/ss knock", "dark_purple"), b("[Whisper]\n", "/ss whisper", "dark_purple"),
                 b("[Sound]\n", "/ss sound", "dark_purple"),
                 b("[Torch]  ", "/ss torch", "dark_purple"), b("[Door]  ", "/ss door", "dark_purple"), b("[Theft]", "/ss theft", "dark_purple")),
            page(t("STORY\n", "dark_red"),
                 b("[Stage 0]  ", "/ss stage 0", "dark_green"), b("[Stage 1]\n", "/ss stage 1", "dark_green"),
                 b("[Stage 2]  ", "/ss stage 2", "dark_green"), b("[Stage 3]\n", "/ss stage 3", "dark_green"),
                 b("[Stage 4]  ", "/ss stage 4", "dark_green"), b("[Stage 5]\n\n", "/ss stage 5", "dark_green"),
                 b("[Reset all]\n", "/ss reset", "dark_green"),
                 b("[New guide]", "/ss guide", "dark_green"))
        };
    }
}
