package com.spoiledseed.config;

import java.io.File;
import net.minecraftforge.common.config.Configuration;

public class ModConfig {
    // timing
    public static int graceSeconds = 600;
    public static int eventIntervalSeconds = 180;
    public static int jumpscareCooldownSeconds = 300;
    // gameplay
    public static float eventProbability = 0.7F;
    public static int chaseDurationSeconds = 25;
    public static float chaseSpeed = 0.31F;
    public static float chaseDamage = 3.0F;
    public static float chaseKillChance = 0.25F;     // chance the catch is lethal (never at quest stage 0)
    public static float chaseScareChance = 0.35F;    // chance the catch is a jumpscare instead of a hit
    public static float rushChance = 0.5F;           // chance it RUNS at you when you stare at it (quest stage >= 1)
    public static float rushKillChance = 0.35F;      // a rush ends in a kill, otherwise in a jumpscare
    public static boolean jumpscareEnabled = true;
    public static boolean theftEnabled = true;
    public static boolean affectCreative = false;
    public static int homeRadius = 40;
    public static float caveRunChance = 0.10F;
    public static int maxSigns = 6;
    // fog
    public static boolean fogEnabled = true;
    public static float fogBaseline = 0.18F;
    public static float fogEpisodeChance = 0.004F;
    public static float fogBeforeEncounterChance = 0.4F;
    // world
    public static boolean structuresEnabled = true;
    public static int structureRegionChunks = 10;
    // convenience
    public static boolean openCommands = true;
    public static boolean giveGuideBook = true;

    public static void load(File file) {
        Configuration c = new Configuration(file);
        String t = "timing";
        graceSeconds = c.getInt("graceSeconds", t, graceSeconds, 0, 1000000, "Seconds of play before the monster's events can start (per player).");
        eventIntervalSeconds = c.getInt("eventIntervalSeconds", t, eventIntervalSeconds, 20, 100000, "Base seconds between events. Shrinks with play time, night, threat and near home.");
        jumpscareCooldownSeconds = c.getInt("jumpscareCooldownSeconds", t, jumpscareCooldownSeconds, 10, 100000, "Minimum seconds between NATURAL jumpscares (commands and traps ignore it).");
        String g = "gameplay";
        eventProbability = c.getFloat("eventProbability", g, eventProbability, 0F, 1F, "Base chance that an event fires when its timer expires.");
        chaseDurationSeconds = c.getInt("chaseDurationSeconds", g, chaseDurationSeconds, 5, 600, "Average chase length in seconds.");
        chaseSpeed = c.getFloat("chaseSpeed", g, chaseSpeed, 0.1F, 0.6F, "Movement speed of The Null while chasing (threat adds a bit).");
        chaseDamage = c.getFloat("chaseDamage", g, chaseDamage, 0F, 20F, "Damage of a normal hit (2.0 = one heart).");
        chaseKillChance = c.getFloat("chaseKillChance", g, chaseKillChance, 0F, 1F, "Chance that being caught in a chase kills you. Never at quest stage 0.");
        chaseScareChance = c.getFloat("chaseScareChance", g, chaseScareChance, 0F, 1F, "Chance that being caught triggers a jumpscare instead of a hit.");
        rushChance = c.getFloat("rushChance", g, rushChance, 0F, 1F, "Chance that it charges at you when you look at it too long (stage >= 1).");
        rushKillChance = c.getFloat("rushKillChance", g, rushKillChance, 0F, 1F, "A charge ends in a kill with this chance, otherwise in a jumpscare.");
        jumpscareEnabled = c.getBoolean("jumpscareEnabled", g, jumpscareEnabled, "Allow natural jumpscares.");
        theftEnabled = c.getBoolean("theftEnabled", g, theftEnabled, "Allow The Null to take items from chests YOU placed (always recoverable).");
        affectCreative = c.getBoolean("affectCreative", g, affectCreative, "Run monster events on creative/spectator players.");
        homeRadius = c.getInt("homeRadius", g, homeRadius, 10, 200, "Radius around your bed / spawn point where it is more active.");
        caveRunChance = c.getFloat("caveRunChance", g, caveRunChance, 0F, 1F, "Chance per ore mined underground that something runs through the cave.");
        maxSigns = c.getInt("maxSigns", g, maxSigns, 1, 30, "Maximum cursed signs alive per player.");
        String f = "fog";
        fogEnabled = c.getBoolean("fogEnabled", f, fogEnabled, "Master switch for the Black Fog. Each player can also toggle it in Mod Options.");
        fogBaseline = c.getFloat("fogBaseline", f, fogBaseline, 0F, 1F, "Constant fog strength from the moment you spawn.");
        fogEpisodeChance = c.getFloat("fogEpisodeChance", f, fogEpisodeChance, 0F, 1F, "Chance per second that a thicker fog episode starts by itself.");
        fogBeforeEncounterChance = c.getFloat("fogBeforeEncounterChance", f, fogBeforeEncounterChance, 0F, 1F, "Chance that fog rolls in seconds before an encounter.");
        String w = "world";
        structuresEnabled = c.getBoolean("structuresEnabled", w, structuresEnabled, "Generate the corrupted structures.");
        structureRegionChunks = c.getInt("structureRegionChunks", w, structureRegionChunks, 4, 32, "Every NxN-chunk region holds exactly 3 Sites, 1 Shrine, 1 Cairn and 1 Ruin.");
        String o = "convenience";
        openCommands = c.getBoolean("openCommands", o, openCommands, "true = everyone can use /ss (no cheats needed). false = operators only.");
        giveGuideBook = c.getBoolean("giveGuideBook", o, giveGuideBook, "Give the Survivor's Guide on first join and after every respawn.");
        if (c.hasChanged()) c.save();
    }
}
