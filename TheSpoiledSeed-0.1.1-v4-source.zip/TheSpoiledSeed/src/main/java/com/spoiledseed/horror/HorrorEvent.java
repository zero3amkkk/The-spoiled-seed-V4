package com.spoiledseed.horror;

/** Every event the director can fire. 'key' is what /ss accepts. */
public enum HorrorEvent {
    OBSERVE("observe"), GLIMPSE("glimpse"), STALK("stalk"), CHASE("chase"), BED("bed"),
    JUMPSCARE("jumpscare"),
    FOOTSTEPS("footsteps"), KNOCK("knock"), WHISPER("whisper"), SOUND("sound"), CAVE("cave"),
    TORCH("torch"), DOOR("door"), THEFT("theft"), SIGN("sign"),
    WINDOW("window"), MIMIC("mimic"), ECHO("echo"), BLACKOUT("blackout");

    public final String key;

    HorrorEvent(String key) { this.key = key; }

    public boolean spawnsNull() {
        return this == OBSERVE || this == GLIMPSE || this == STALK || this == CHASE || this == BED || this == WINDOW;
    }

    public static HorrorEvent byKey(String s) {
        for (HorrorEvent e : values()) if (e.key.equalsIgnoreCase(s) || e.name().equalsIgnoreCase(s)) return e;
        return null;
    }
}
